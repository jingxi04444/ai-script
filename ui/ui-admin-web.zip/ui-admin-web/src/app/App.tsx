import { useEffect, useMemo, useState } from 'react';
import {
  BarChart3,
  BookOpen,
  ClipboardCheck,
  FolderOpen,
  LayoutDashboard,
  Link2,
  Settings,
  UserCircle2,
} from 'lucide-react';
import AdminHeader from './components/AdminHeader';
import AdminSidebar from './components/AdminSidebar';
import AnalyticsBoard from './components/AnalyticsBoard';
import DataCollection from './components/DataCollection';
import KnowledgeBase from './components/KnowledgeBase';
import Overview from './components/Overview';
import ProfileCenter from './components/ProfileCenter';
import ProjectAssets from './components/ProjectAssets';
import ReviewWorkflow from './components/ReviewWorkflow';
import SystemSettings from './components/SystemSettings';

type RoleId = 'super-admin' | 'brand-admin' | 'reviewer' | 'ops';
type ShellTheme = 'default' | 'oled';

const roleOptions: Array<{ value: RoleId; label: string }> = [
  { value: 'super-admin', label: '系统超级管理员' },
  { value: 'brand-admin', label: '品牌专属管理员' },
  { value: 'reviewer', label: '审核员' },
  { value: 'ops', label: '技术运维' },
];

const tenantOptions = [
  { value: 'all', label: '全部品牌' },
  { value: 'boqi', label: '泊其品牌' },
  { value: 'nova', label: 'Nova 厨电' },
  { value: 'luma', label: 'Luma 个护' },
];

const modules = [
  {
    id: 'profile',
    section: '账号中心',
    label: '个人信息',
    caption: '查看账号资料、安全设置与界面偏好。',
    icon: UserCircle2,
    roles: ['super-admin', 'brand-admin', 'reviewer', 'ops'],
    stage: 'mvp' as const,
    children: [
      { id: 'personal-info', label: '基础资料' },
      { id: 'account-security', label: '安全设置' },
    ],
    quickActions: ['编辑个人资料', '修改密码', '切换主题'],
  },
  {
    id: 'overview',
    section: '工作台',
    label: '总览',
    caption: '统一查看租户、审核、解析和权限治理的当前状态。',
    icon: LayoutDashboard,
    roles: ['super-admin', 'brand-admin', 'reviewer', 'ops'],
    stage: 'mvp' as const,
    children: [
      { id: 'dashboard', label: '平台看板' },
      { id: 'tenant-risk', label: '租户态势' },
      { id: 'priority-actions', label: '优先动作' },
    ],
    quickActions: ['创建租户巡检', '新增风险事项', '生成周报'],
  },
  {
    id: 'collection',
    section: '内容治理',
    label: '数据采集',
    caption: '配置解析 API、插件授权、解析日志和清洗规则。',
    icon: Link2,
    roles: ['super-admin', 'ops'],
    stage: 'mvp' as const,
    children: [
      { id: 'api-config', label: '解析 API' },
      { id: 'plugin-auth', label: '插件授权' },
      { id: 'parse-logs', label: '解析日志' },
      { id: 'clean-rules', label: '清洗规则' },
    ],
    quickActions: ['新增解析服务商', '发布插件版本', '导出解析日志'],
  },
  {
    id: 'knowledge',
    section: '内容治理',
    label: '知识库',
    caption: '管理品牌私有结构公式、卖点知识和公共合规词库。',
    icon: BookOpen,
    roles: ['super-admin', 'brand-admin'],
    stage: 'mvp' as const,
    children: [
      { id: 'formula-library', label: '结构公式' },
      { id: 'selling-points', label: '卖点知识' },
      { id: 'compliance-dictionary', label: '合规词库' },
      { id: 'tag-system', label: '标签体系' },
    ],
    quickActions: ['新增结构公式', '导入卖点 CSV', '新增合规词'],
  },
  {
    id: 'review',
    section: '内容治理',
    label: '审核工作流',
    caption: '管理审核席位、任务分配、审核记录和规则配置。',
    icon: ClipboardCheck,
    roles: ['super-admin', 'brand-admin', 'reviewer'],
    stage: 'mvp' as const,
    children: [
      { id: 'reviewers', label: '审核席位' },
      { id: 'tasks', label: '审核任务' },
      { id: 'rules', label: '审核规则' },
      { id: 'records', label: '审核记录' },
    ],
    quickActions: ['分配审核任务', '创建审核规则', '导出审核记录'],
  },
  {
    id: 'assets',
    section: '内容治理',
    label: '项目素材',
    caption: '查看项目、素材、存储占用与复用统计。',
    icon: FolderOpen,
    roles: ['super-admin', 'brand-admin'],
    stage: 'extended' as const,
    children: [
      { id: 'projects', label: '项目库' },
      { id: 'materials', label: '素材库' },
      { id: 'storage', label: '存储管理' },
      { id: 'reuse-report', label: '复用报告' },
    ],
    quickActions: ['新建项目归档', '批量导出素材', '生成复用报告'],
  },
  {
    id: 'analytics',
    section: '工作台',
    label: '投放数据',
    caption: '高阶数据看板、趋势分析和 A/B 测试报告预留。',
    icon: BarChart3,
    roles: ['super-admin', 'brand-admin'],
    stage: 'future' as const,
    children: [
      { id: 'data-screen', label: '数据大屏' },
      { id: 'trend-analysis', label: '趋势分析' },
      { id: 'ab-report', label: 'A/B 报告' },
    ],
    quickActions: ['生成趋势快照', '导出 A/B 报告', '创建监测链接'],
  },
  {
    id: 'system',
    section: '系统治理',
    label: '系统权限',
    caption: '配置租户、外部 API、用户权限、日志与监控告警。',
    icon: Settings,
    roles: ['super-admin'],
    stage: 'mvp' as const,
    children: [
      { id: 'tenant-config', label: '租户配置' },
      { id: 'api-config', label: 'API 管理' },
      { id: 'user-permissions', label: '用户权限' },
      { id: 'audit-monitor', label: '日志监控' },
    ],
    quickActions: ['新增品牌租户', '新建角色权限', '配置告警规则'],
  },
];

function firstAllowedModule(role: RoleId) {
  return modules.find((module) => module.roles.includes(role))?.id ?? 'overview';
}

function firstSubmodule(moduleId: string) {
  return modules.find((module) => module.id === moduleId)?.children[0]?.id ?? '';
}

export default function App() {
  const [role, setRole] = useState<RoleId>('super-admin');
  const [tenant, setTenant] = useState('all');
  const [activeModule, setActiveModule] = useState(firstAllowedModule('super-admin'));
  const [activeSubmodule, setActiveSubmodule] = useState(firstSubmodule(firstAllowedModule('super-admin')));
  const [shellTheme, setShellTheme] = useState<ShellTheme>(() => {
    if (typeof window === 'undefined') {
      return 'default';
    }

    return window.localStorage.getItem('ui-admin-shell-theme') === 'oled' ? 'oled' : 'default';
  });
  const [favoriteViews, setFavoriteViews] = useState<string[]>(['overview:dashboard', 'review:tasks']);

  useEffect(() => {
    document.documentElement.classList.add('dark');
    document.documentElement.dataset.shellTheme = shellTheme;

    if (typeof window !== 'undefined') {
      window.localStorage.setItem('ui-admin-shell-theme', shellTheme);
    }

    return () => {
      document.documentElement.classList.remove('dark');
      delete document.documentElement.dataset.shellTheme;
    };
  }, [shellTheme]);

  useEffect(() => {
    const currentModule = modules.find((module) => module.id === activeModule);

    if (!currentModule || !currentModule.roles.includes(role)) {
      setActiveModule(firstAllowedModule(role));
      return;
    }

    if (!currentModule.children.some((item) => item.id === activeSubmodule)) {
      setActiveSubmodule(currentModule.children[0]?.id ?? '');
    }
  }, [activeModule, activeSubmodule, role]);

  const activeModuleMeta = useMemo(
    () => modules.find((module) => module.id === activeModule) ?? modules[0],
    [activeModule],
  );
  const activeSubmoduleMeta =
    activeModuleMeta.children.find((child) => child.id === activeSubmodule) ?? activeModuleMeta.children[0];

  const roleLabel = roleOptions.find((option) => option.value === role)?.label ?? '系统超级管理员';
  const tenantLabel = tenantOptions.find((option) => option.value === tenant)?.label ?? '全部品牌';
  const userInfo = {
    'super-admin': { name: '林策', email: 'lince@aiscript.local' },
    'brand-admin': { name: '王乔', email: 'wangqiao@tenant.local' },
    reviewer: { name: '李墨', email: 'limo@review.local' },
    ops: { name: '周衡', email: 'zhouheng@ops.local' },
  }[role];

  const handleThemeToggle = () => {
    setShellTheme((currentTheme) => (currentTheme === 'default' ? 'oled' : 'default'));
  };

  const currentFavoriteKey = `${activeModule}:${activeSubmodule}`;
  const isCurrentViewFavorited = favoriteViews.includes(currentFavoriteKey);

  const favoriteEntries = favoriteViews
    .map((entry) => {
      const [moduleId, subId] = entry.split(':');
      const moduleMeta = modules.find((module) => module.id === moduleId);
      const subMeta = moduleMeta?.children.find((child) => child.id === subId);

      if (!moduleMeta || !subMeta) {
        return null;
      }

      return {
        key: entry,
        moduleId,
        subId,
        label: subMeta.label,
        moduleLabel: moduleMeta.label,
      };
    })
    .filter(Boolean) as Array<{ key: string; moduleId: string; subId: string; label: string; moduleLabel: string }>;

  const toggleFavoriteCurrentView = () => {
    setFavoriteViews((currentFavorites) =>
      currentFavorites.includes(currentFavoriteKey)
        ? currentFavorites.filter((item) => item !== currentFavoriteKey)
        : [...currentFavorites, currentFavoriteKey],
    );
  };

  const handleModuleChange = (moduleId: string) => {
    setActiveModule(moduleId);
    setActiveSubmodule(firstSubmodule(moduleId));
  };

  const handleFavoriteSelect = (entry: { moduleId: string; subId: string }) => {
    setActiveModule(entry.moduleId);
    setActiveSubmodule(entry.subId);
  };

  const handleLogout = () => {
    setRole('super-admin');
    setTenant('all');
    setActiveModule(firstAllowedModule('super-admin'));
    setActiveSubmodule(firstSubmodule(firstAllowedModule('super-admin')));
  };

  const handleOpenProfilePage = () => {
    setActiveModule('profile');
    setActiveSubmodule('personal-info');
  };

  let content = (
    <Overview
      roleLabel={roleLabel}
      tenantLabel={tenantLabel}
      activeView={activeSubmodule}
      onViewChange={setActiveSubmodule}
    />
  );

  if (activeModule === 'collection') {
    content = <DataCollection activeView={activeSubmodule} onViewChange={setActiveSubmodule} />;
  } else if (activeModule === 'profile') {
    content = (
      <ProfileCenter
        activeView={activeSubmodule}
        onViewChange={setActiveSubmodule}
        userName={userInfo.name}
        userEmail={userInfo.email}
        roleLabel={roleLabel}
        shellTheme={shellTheme}
      />
    );
  } else if (activeModule === 'knowledge') {
    content = <KnowledgeBase tenantLabel={tenantLabel} activeView={activeSubmodule} onViewChange={setActiveSubmodule} />;
  } else if (activeModule === 'review') {
    content = <ReviewWorkflow activeView={activeSubmodule} onViewChange={setActiveSubmodule} />;
  } else if (activeModule === 'assets') {
    content = <ProjectAssets activeView={activeSubmodule} onViewChange={setActiveSubmodule} />;
  } else if (activeModule === 'analytics') {
    content = <AnalyticsBoard activeView={activeSubmodule} onViewChange={setActiveSubmodule} />;
  } else if (activeModule === 'system') {
    content = <SystemSettings activeView={activeSubmodule} onViewChange={setActiveSubmodule} />;
  }

  return (
    <div className="min-h-screen text-slate-50">
      <div className="mx-auto min-h-screen max-w-[1800px] lg:grid lg:grid-cols-[248px_minmax(0,1fr)] lg:gap-0">
        <AdminSidebar
          modules={modules}
          activeModule={activeModule}
          activeSubmodule={activeSubmodule}
          activeRole={role}
          activeTenantLabel={tenantLabel}
          onModuleChange={handleModuleChange}
          onSubmoduleChange={setActiveSubmodule}
        />

        <div className="min-w-0 border-t border-white/10 bg-[rgba(2,6,23,0.35)] lg:border-l lg:border-t-0">
          <AdminHeader
            moduleSection={activeModuleMeta.section}
            moduleTitle={activeModuleMeta.label}
            submoduleTitle={activeSubmoduleMeta?.label ?? activeModuleMeta.label}
            moduleCaption={activeModuleMeta.caption}
            role={role}
            roleLabel={roleLabel}
            tenant={tenant}
            tenantLabel={tenantLabel}
            userName={userInfo.name}
            userEmail={userInfo.email}
            shellTheme={shellTheme}
            quickActions={activeModuleMeta.quickActions}
            favorites={favoriteEntries}
            isCurrentViewFavorited={isCurrentViewFavorited}
            roleOptions={roleOptions}
            tenantOptions={tenantOptions}
            onRoleChange={(nextRole) => setRole(nextRole as RoleId)}
            onTenantChange={setTenant}
            onThemeToggle={handleThemeToggle}
            onOpenProfile={handleOpenProfilePage}
            onToggleFavoriteCurrent={toggleFavoriteCurrentView}
            onFavoriteSelect={handleFavoriteSelect}
            onLogout={handleLogout}
          />

          <main className="px-4 py-6 sm:px-6 lg:px-8">
            <div className="mx-auto w-full max-w-[1320px]">{content}</div>
          </main>
        </div>
      </div>
    </div>
  );
}
