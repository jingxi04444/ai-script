import { useEffect, useRef, useState } from 'react';
import { Bell, Building2, LogOut, MoonStar, Plus, Search, Shield, Star } from 'lucide-react';
import { ActionButton, StatusBadge } from './shared';

interface AdminHeaderProps {
  moduleSection: string;
  moduleTitle: string;
  submoduleTitle: string;
  moduleCaption: string;
  role: string;
  roleLabel: string;
  tenant: string;
  tenantLabel: string;
  userName: string;
  userEmail: string;
  shellTheme: 'default' | 'oled';
  quickActions: string[];
  favorites: Array<{ key: string; moduleId: string; subId: string; label: string; moduleLabel: string }>;
  isCurrentViewFavorited: boolean;
  roleOptions: Array<{ value: string; label: string }>;
  tenantOptions: Array<{ value: string; label: string }>;
  onRoleChange: (role: string) => void;
  onTenantChange: (tenant: string) => void;
  onThemeToggle: () => void;
  onOpenProfile: () => void;
  onToggleFavoriteCurrent: () => void;
  onFavoriteSelect: (entry: { moduleId: string; subId: string }) => void;
  onLogout: () => void;
}

export default function AdminHeader({
  moduleSection,
  moduleTitle,
  submoduleTitle,
  moduleCaption,
  role,
  roleLabel,
  tenant,
  tenantLabel,
  userName,
  userEmail,
  shellTheme,
  quickActions,
  favorites,
  isCurrentViewFavorited,
  roleOptions,
  tenantOptions,
  onRoleChange,
  onTenantChange,
  onThemeToggle,
  onOpenProfile,
  onToggleFavoriteCurrent,
  onFavoriteSelect,
  onLogout,
}: AdminHeaderProps) {
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  const [isQuickCreateOpen, setIsQuickCreateOpen] = useState(false);
  const favoritesRef = useRef<HTMLDivElement>(null);
  const quickCreateRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isFavoritesOpen && !isQuickCreateOpen) {
      return undefined;
    }

    const handleClickOutside = (event: MouseEvent) => {
      if (favoritesRef.current && !favoritesRef.current.contains(event.target as Node)) {
        setIsFavoritesOpen(false);
      }

      if (quickCreateRef.current && !quickCreateRef.current.contains(event.target as Node)) {
        setIsQuickCreateOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isFavoritesOpen, isQuickCreateOpen]);

  const userInitial = userName.slice(0, 1);
  const themeLabel = shellTheme === 'default' ? '标准暗色' : 'OLED 暗色';

  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-[rgba(2,6,23,0.82)] backdrop-blur-xl">
      <div className="mx-auto flex w-full max-w-[1320px] flex-col gap-4 px-5 py-4 lg:px-8">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 text-sm text-slate-400">
              <span>后台管理</span>
              <span>/</span>
              <span>{moduleSection}</span>
              <span>/</span>
              <span className="text-slate-200">{moduleTitle}</span>
              <span>/</span>
              <span className="text-[#bbf7d0]">{submoduleTitle}</span>
            </div>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-400">{moduleCaption}</p>
          </div>

          <div className="flex flex-wrap items-center gap-2 xl:justify-end">
            <button
              type="button"
              onClick={onOpenProfile}
              className="flex min-h-11 cursor-pointer items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-3 pr-4 text-left text-slate-200 hover:border-white/20 hover:bg-white/10"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-2xl border border-[#22c55e]/30 bg-[#22c55e]/10 text-sm font-semibold text-[#bbf7d0]">
                {userInitial}
              </div>
              <div>
                <div className="text-sm font-medium text-slate-50">{userName}</div>
                <div className="text-xs text-slate-500">{userEmail}</div>
              </div>
            </button>

            <button
              type="button"
              onClick={onLogout}
              className="flex min-h-11 cursor-pointer items-center gap-2 rounded-2xl border border-orange-400/20 bg-orange-400/10 px-4 text-sm text-orange-100 hover:bg-orange-400/15"
            >
              <LogOut className="h-4 w-4" />
              退出
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          

          <button
            type="button"
            aria-label="查看系统告警"
            className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-slate-200 hover:border-white/20 hover:bg-white/10"
          >
            <Bell className="h-5 w-5" />
          </button>

          <button
            type="button"
            onClick={onThemeToggle}
            className="flex min-h-11 cursor-pointer items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 text-sm text-slate-200 hover:border-white/20 hover:bg-white/10"
          >
            <MoonStar className="h-4 w-4 text-[#22c55e]" />
            <span>主题：{themeLabel}</span>
          </button>

          <div className="relative" ref={favoritesRef}>
            <button
              type="button"
              onClick={() => setIsFavoritesOpen((open) => !open)}
              className="flex min-h-11 cursor-pointer items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 text-sm text-slate-200 hover:border-white/20 hover:bg-white/10"
            >
              <Star className={`h-4 w-4 ${isCurrentViewFavorited ? 'fill-[#22c55e] text-[#22c55e]' : 'text-slate-300'}`} />
              <span>收藏菜单</span>
            </button>

            {isFavoritesOpen && (
              <div className="absolute left-0 top-full mt-3 w-[320px] rounded-[26px] border border-white/10 bg-[rgba(2,6,23,0.96)] p-4 shadow-[0_24px_60px_rgba(2,6,23,0.55)] backdrop-blur-xl">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-slate-50">常用页面收藏</div>
                    <div className="mt-1 text-xs text-slate-500">可快速跳转到常访问的模块二级页</div>
                  </div>
                  <ActionButton
                    label={isCurrentViewFavorited ? '取消当前收藏' : '收藏当前页'}
                    icon={Star}
                    tone={isCurrentViewFavorited ? 'danger' : 'accent'}
                    className="px-3"
                    onClick={onToggleFavoriteCurrent}
                  />
                </div>

                <div className="mt-4 space-y-2">
                  {favorites.length > 0 ? (
                    favorites.map((favorite) => (
                      <button
                        key={favorite.key}
                        type="button"
                        onClick={() => {
                          onFavoriteSelect({ moduleId: favorite.moduleId, subId: favorite.subId });
                          setIsFavoritesOpen(false);
                        }}
                        className="flex min-h-11 w-full cursor-pointer items-center justify-between rounded-2xl border border-white/10 bg-white/[0.03] px-4 text-left text-sm text-slate-200 hover:bg-white/[0.05]"
                      >
                        <div>
                          <div className="font-medium text-slate-50">{favorite.label}</div>
                          <div className="mt-1 text-xs text-slate-500">{favorite.moduleLabel}</div>
                        </div>
                        <Star className="h-4 w-4 fill-[#22c55e] text-[#22c55e]" />
                      </button>
                    ))
                  ) : (
                    <div className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-4 text-sm text-slate-500">
                      还没有收藏页面，可将当前模块二级页加入常用菜单。
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="relative" ref={quickCreateRef}>
            <button
              type="button"
              onClick={() => setIsQuickCreateOpen((open) => !open)}
              className="flex min-h-11 cursor-pointer items-center gap-2 rounded-2xl border border-[#22c55e]/30 bg-[#22c55e]/10 px-4 text-sm text-[#bbf7d0] hover:bg-[#22c55e]/15"
            >
              <Plus className="h-4 w-4" />
              快捷新建
            </button>

            {isQuickCreateOpen && (
              <div className="absolute left-0 top-full mt-3 w-[280px] rounded-[26px] border border-white/10 bg-[rgba(2,6,23,0.96)] p-4 shadow-[0_24px_60px_rgba(2,6,23,0.55)] backdrop-blur-xl">
                <div className="text-sm font-semibold text-slate-50">{moduleTitle} 快捷新建</div>
                <div className="mt-1 text-xs text-slate-500">根据当前模块推荐常用的新建动作</div>
                <div className="mt-4 space-y-2">
                  {quickActions.map((action) => (
                    <button
                      key={action}
                      type="button"
                      onClick={() => setIsQuickCreateOpen(false)}
                      className="flex min-h-11 w-full cursor-pointer items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-4 text-left text-sm text-slate-200 hover:bg-white/[0.05]"
                    >
                      <Plus className="h-4 w-4 text-[#22c55e]" />
                      <span>{action}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

       

    
      </div>
    </header>
  );
}
