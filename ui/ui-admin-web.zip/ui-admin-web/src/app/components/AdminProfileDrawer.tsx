import { BellRing, LockKeyhole, MoonStar, ShieldCheck, UserCircle2 } from 'lucide-react';
import { ActionButton, SideDrawer, StatusBadge } from './shared';

export default function AdminProfileDrawer({
  open,
  userName,
  userEmail,
  roleLabel,
  tenantLabel,
  shellTheme,
  onClose,
  onThemeToggle,
  onLogout,
}: {
  open: boolean;
  userName: string;
  userEmail: string;
  roleLabel: string;
  tenantLabel: string;
  shellTheme: 'default' | 'oled';
  onClose: () => void;
  onThemeToggle: () => void;
  onLogout: () => void;
}) {
  return (
    <SideDrawer
      open={open}
      title="个人设置"
      description="管理当前管理员账号的基础信息、界面偏好和安全策略。"
      onClose={onClose}
      footer={
        <div className="flex flex-wrap justify-end gap-3">
          <ActionButton label="关闭" onClick={onClose} />
          <ActionButton label="退出当前会话" tone="danger" onClick={onLogout} />
        </div>
      }
    >
      <div className="space-y-6">
        <section className="rounded-[24px] border border-white/10 bg-white/[0.03] p-4">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-[20px] border border-[#22c55e]/30 bg-[#22c55e]/10 text-lg font-semibold text-[#bbf7d0]">
              {userName.slice(0, 1)}
            </div>
            <div className="min-w-0">
              <div className="text-lg font-semibold text-slate-50">{userName}</div>
              <div className="mt-1 text-sm text-slate-400">{roleLabel}</div>
              <div className="mt-1 break-all text-xs text-slate-500">{userEmail}</div>
              <div className="mt-3 flex flex-wrap gap-2">
                <StatusBadge label={`租户范围：${tenantLabel}`} tone="neutral" />
                <StatusBadge label="MFA 已启用" tone="success" />
              </div>
            </div>
          </div>
        </section>

        <section className="rounded-[24px] border border-white/10 bg-white/[0.03] p-4">
          <div className="flex items-center gap-3 text-slate-50">
            <UserCircle2 className="h-5 w-5 text-[#22c55e]" />
            账号信息
          </div>
          <div className="mt-4 grid gap-3 text-sm text-slate-300">
            <div className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3">姓名：{userName}</div>
            <div className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3">角色：{roleLabel}</div>
            <div className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3">邮箱：{userEmail}</div>
          </div>
        </section>

        <section className="rounded-[24px] border border-white/10 bg-white/[0.03] p-4">
          <div className="flex items-center gap-3 text-slate-50">
            <MoonStar className="h-5 w-5 text-sky-300" />
            界面偏好
          </div>
          <p className="mt-2 text-sm leading-6 text-slate-400">当前主题：{shellTheme === 'default' ? '标准暗色' : 'OLED 暗色'}。可在不同光线环境下切换更合适的后台壳层样式。</p>
          <div className="mt-4 flex flex-wrap gap-3">
            <ActionButton label="切换主题" icon={MoonStar} tone="accent" onClick={onThemeToggle} />
            <ActionButton label="通知偏好" icon={BellRing} />
          </div>
        </section>

        <section className="rounded-[24px] border border-white/10 bg-white/[0.03] p-4">
          <div className="flex items-center gap-3 text-slate-50">
            <ShieldCheck className="h-5 w-5 text-emerald-300" />
            安全设置
          </div>
          <div className="mt-4 space-y-3 text-sm text-slate-300">
            <div className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3">登录方式：账号密码 + 二次验证</div>
            <div className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3">最近登录设备：MacBook Pro / 10.10.12.28</div>
            <div className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3">会话超时时间：30 分钟</div>
          </div>
          <div className="mt-4 flex flex-wrap gap-3">
            <ActionButton label="修改密码" icon={LockKeyhole} />
            <ActionButton label="查看登录记录" icon={ShieldCheck} />
          </div>
        </section>
      </div>
    </SideDrawer>
  );
}
