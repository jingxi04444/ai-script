import type { LucideIcon } from 'lucide-react';
import { Search, X } from 'lucide-react';
import type { ReactNode } from 'react';

export type Tone = 'neutral' | 'accent' | 'success' | 'warning';

function toneClassName(tone: Tone) {
  if (tone === 'accent') {
    return 'border-[#22c55e]/30 bg-[#22c55e]/10 text-[#bbf7d0]';
  }

  if (tone === 'success') {
    return 'border-emerald-400/20 bg-emerald-400/10 text-emerald-200';
  }

  if (tone === 'warning') {
    return 'border-amber-400/30 bg-amber-400/10 text-amber-100';
  }

  return 'border-white/10 bg-white/5 text-slate-200';
}

export function StatusBadge({ label, tone = 'neutral' }: { label: string; tone?: Tone }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium ${toneClassName(tone)}`}>
      {label}
    </span>
  );
}

export function ActionButton({
  label,
  icon: Icon,
  tone = 'neutral',
  onClick,
  className = '',
}: {
  label: string;
  icon?: LucideIcon;
  tone?: 'neutral' | 'accent' | 'danger';
  onClick?: () => void;
  className?: string;
}) {
  const toneClass =
    tone === 'accent'
      ? 'border-[#22c55e]/30 bg-[#22c55e]/10 text-[#bbf7d0] hover:bg-[#22c55e]/15'
      : tone === 'danger'
        ? 'border-orange-400/20 bg-orange-400/10 text-orange-100 hover:bg-orange-400/15'
        : 'border-white/10 bg-white/5 text-slate-200 hover:bg-white/10';

  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex min-h-10 cursor-pointer items-center gap-2 rounded-xl border px-4 text-sm ${toneClass} ${className}`}
    >
      {Icon && <Icon className="h-4 w-4" />}
      <span>{label}</span>
    </button>
  );
}

export function SectionTabs({
  items,
  activeItem,
  onChange,
}: {
  items: Array<{ id: string; label: string }>;
  activeItem: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((item) => (
        <button
          key={item.id}
          type="button"
          onClick={() => onChange(item.id)}
          className={`min-h-10 cursor-pointer rounded-full border px-4 text-sm ${
            activeItem === item.id
              ? 'border-[#22c55e]/35 bg-[#22c55e]/10 text-[#bbf7d0]'
              : 'border-white/10 bg-white/5 text-slate-400 hover:border-white/20 hover:text-slate-200'
          }`}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

export function CrudToolbar({
  searchPlaceholder,
  filters = [],
  right,
}: {
  searchPlaceholder: string;
  filters?: string[];
  right?: ReactNode;
}) {
  return (
    <div className="mb-4 flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
      <div className="flex flex-1 flex-col gap-3 lg:flex-row lg:items-center">
        <label className="relative block lg:min-w-[320px] xl:max-w-[420px] xl:flex-1">
          <span className="sr-only">搜索</span>
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            type="search"
            placeholder={searchPlaceholder}
            className="w-full rounded-2xl border border-white/10 bg-white/5 py-3 pl-11 pr-4 text-sm text-slate-100 placeholder:text-slate-500 focus:border-[#22c55e]/50 focus:outline-none"
          />
        </label>
        <div className="flex flex-wrap gap-2">
          {filters.map((filter) => (
            <ActionButton key={filter} label={filter} className="px-3" />
          ))}
        </div>
      </div>
      {right}
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  tags,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  tags?: Array<{ label: string; tone?: Tone }>;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <div className="text-xs font-medium uppercase tracking-[0.24em] text-slate-400">{eyebrow}</div>
        <h1 className="mt-3 text-3xl font-semibold text-slate-50 sm:text-4xl">{title}</h1>
        <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-400 sm:text-base">{description}</p>
        {tags && tags.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {tags.map((tag) => (
              <StatusBadge key={tag.label} label={tag.label} tone={tag.tone} />
            ))}
          </div>
        )}
      </div>
      {action}
    </div>
  );
}

export function Panel({
  title,
  description,
  action,
  children,
  className = '',
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={`rounded-[28px] border border-white/10 bg-[rgba(15,23,42,0.82)] p-5 shadow-[0_20px_60px_rgba(2,6,23,0.5)] backdrop-blur-xl sm:p-6 ${className}`}
    >
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-50">{title}</h2>
          {description && <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">{description}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

export function MetricCard({
  label,
  value,
  detail,
  tone = 'neutral',
}: {
  label: string;
  value: string;
  detail: string;
  tone?: Tone;
}) {
  const accentDot = tone === 'warning' ? 'bg-amber-400' : tone === 'accent' ? 'bg-[#22c55e]' : tone === 'success' ? 'bg-emerald-400' : 'bg-slate-500';

  return (
    <div className="rounded-[24px] border border-white/10 bg-[rgba(2,6,23,0.55)] p-5">
      <div className="flex items-center justify-between">
        <span className="text-sm text-slate-400">{label}</span>
        <span className={`h-2.5 w-2.5 rounded-full ${accentDot}`} />
      </div>
      <div className="mt-4 text-3xl font-semibold tracking-tight text-slate-50">{value}</div>
      <p className="mt-3 text-sm leading-6 text-slate-400">{detail}</p>
    </div>
  );
}

export function ProgressRow({
  label,
  value,
  caption,
  tone = 'accent',
}: {
  label: string;
  value: number;
  caption: string;
  tone?: Tone;
}) {
  const barClass = tone === 'warning' ? 'bg-amber-400' : tone === 'success' ? 'bg-emerald-400' : tone === 'neutral' ? 'bg-slate-400' : 'bg-[#22c55e]';

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span className="text-slate-200">{label}</span>
        <span className="text-slate-500">{caption}</span>
      </div>
      <div className="h-2 rounded-full bg-white/5">
        <div className={`h-2 rounded-full ${barClass}`} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

export function SideDrawer({
  open,
  title,
  description,
  onClose,
  children,
  footer,
}: {
  open: boolean;
  title: string;
  description?: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
}) {
  if (!open) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/55 backdrop-blur-sm">
      <button type="button" aria-label="关闭抽屉" className="flex-1 cursor-default" onClick={onClose} />
      <div className="flex h-full w-full max-w-[460px] flex-col border-l border-white/10 bg-[rgba(2,6,23,0.98)] shadow-[0_28px_70px_rgba(2,6,23,0.6)]">
        <div className="flex items-start justify-between gap-4 border-b border-white/10 px-6 py-5">
          <div>
            <h2 className="text-xl font-semibold text-slate-50">{title}</h2>
            {description && <p className="mt-2 text-sm leading-6 text-slate-400">{description}</p>}
          </div>
          <button
            type="button"
            aria-label="关闭"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-5">{children}</div>
        {footer && <div className="border-t border-white/10 px-6 py-5">{footer}</div>}
      </div>
    </div>
  );
}
