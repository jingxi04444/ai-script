import { Download, Globe, Link2, Plug, RefreshCcw, Upload } from 'lucide-react';
import { ActionButton, CrudToolbar, MetricCard, PageHeader, Panel, SectionTabs, StatusBadge } from './shared';

const sectionItems = [
  { id: 'api-config', label: '解析 API' },
  { id: 'plugin-auth', label: '插件授权' },
  { id: 'parse-logs', label: '解析日志' },
  { id: 'clean-rules', label: '清洗规则' },
];

const apiProviders = [
  {
    provider: '抖音解析主服务',
    scope: '抖音链接 / 结构化字段',
    priority: '主',
    rateLimit: '800 次/分钟',
    timeout: '3s',
    retry: '2 次',
    status: '可用',
  },
  {
    provider: '小红书解析备服务',
    scope: '小红书图文 / 视频',
    priority: '备',
    rateLimit: '500 次/分钟',
    timeout: '4s',
    retry: '3 次',
    status: '待切换',
  },
  {
    provider: '统一解析网关',
    scope: '清洗 / 格式标准化',
    priority: '中间层',
    rateLimit: '不限',
    timeout: '1.2s',
    retry: '1 次',
    status: '可用',
  },
];

const pluginTenants = [
  { tenant: '泊其品牌', version: 'v2.6.1', status: '已授权', rollout: '100%', note: '核心客户，可手动提取抖音和小红书素材' },
  { tenant: 'Nova 厨电', version: 'v2.6.1', status: '灰度发布', rollout: '40%', note: '新版本验证中，默认关闭自动更新' },
  { tenant: 'Luma 个护', version: '-', status: '待授权', rollout: '0%', note: '等待法务确认插件使用范围' },
];

const parseLogs = [
  {
    time: '2026-04-20 09:42',
    userId: 'U-2038',
    brandId: 'BR-018',
    url: 'douyin.com/video/7423***',
    result: '成功',
    latency: '1.4s',
    api: '抖音解析主服务',
    reason: '-',
  },
  {
    time: '2026-04-20 09:39',
    userId: 'U-2041',
    brandId: 'BR-006',
    url: 'xiaohongshu.com/discovery/item/***',
    result: '失败',
    latency: '4.8s',
    api: '小红书解析备服务',
    reason: '权限不足，等待授权刷新',
  },
  {
    time: '2026-04-20 09:35',
    userId: 'U-1020',
    brandId: 'BR-011',
    url: 'douyin.com/video/7421***',
    result: '成功',
    latency: '1.7s',
    api: '抖音解析主服务',
    reason: '-',
  },
];

const cleaningRules = [
  { rule: '去除冗余尾巴', target: '视频描述 / 评论区复制文本', output: '仅保留核心文案主体', status: '启用' },
  { rule: '表情符标准化', target: '标题、文案', output: '删除无效表情并保留语义词', status: '启用' },
  { rule: '互动字段映射', target: '点赞 / 评论 / 收藏 / 分享', output: '统一转为平台无关字段', status: '启用' },
  { rule: '账号信息裁剪', target: '账号名称 / 简介', output: '保留账号名称与描述摘要', status: '草稿' },
];

export default function DataCollection({ activeView, onViewChange }: { activeView: string; onViewChange: (view: string) => void }) {
  let workspace = (
    <Panel
      title="解析 API 配置"
      description="支持多个第三方视频解析服务商，按主备优先级进行调用并监控连通性。"
      action={<ActionButton label="新增解析服务商" tone="accent" />}
    >
      <CrudToolbar
        searchPlaceholder="搜索服务商、平台能力或 API Key 归属"
        filters={['全部平台', '主 / 备优先级', '可用状态']}
        right={
          <div className="flex flex-wrap gap-2">
            <ActionButton label="批量测试连通性" icon={RefreshCcw} />
            <ActionButton label="导出配置" icon={Download} />
          </div>
        }
      />
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="text-slate-500">
            <tr>
              <th className="pb-3 font-medium">服务商</th>
              <th className="pb-3 font-medium">能力范围</th>
              <th className="pb-3 font-medium">优先级</th>
              <th className="pb-3 font-medium">频率限制</th>
              <th className="pb-3 font-medium">超时</th>
              <th className="pb-3 font-medium">重试</th>
              <th className="pb-3 font-medium">状态</th>
              <th className="pb-3 font-medium">操作</th>
            </tr>
          </thead>
          <tbody>
            {apiProviders.map((item) => (
              <tr key={item.provider} className="border-t border-white/10 text-slate-200">
                <td className="py-4 pr-4 font-medium text-slate-50">{item.provider}</td>
                <td className="py-4 pr-4 text-slate-400">{item.scope}</td>
                <td className="py-4 pr-4">{item.priority}</td>
                <td className="py-4 pr-4 text-slate-400">{item.rateLimit}</td>
                <td className="py-4 pr-4">{item.timeout}</td>
                <td className="py-4 pr-4">{item.retry}</td>
                <td className="py-4 pr-4">
                  <StatusBadge label={item.status} tone={item.status === '可用' ? 'success' : 'warning'} />
                </td>
                <td className="py-4">
                  <div className="flex flex-wrap gap-2">
                    <ActionButton label="编辑" className="px-3" />
                    <ActionButton label="测试连通性" tone="accent" className="px-3" />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );

  if (activeView === 'plugin-auth') {
    workspace = (
      <div className="grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
        <Panel title="浏览器插件版本管理" description="生成 / 管理 Chrome 浏览器插件安装包，控制插件版本更新与灰度发布。">
          <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-5">
            <div className="flex items-center gap-3 text-slate-50">
              <Plug className="h-5 w-5 text-[#22c55e]" />
              当前插件版本 v2.6.1
            </div>
            <p className="mt-3 text-sm leading-6 text-slate-400">支持提取视频链接、文案、互动数据和账号信息。可配置强制更新、灰度发布、授权名单。</p>
            <div className="mt-5 flex flex-wrap gap-2">
              <ActionButton label="发布新版本" tone="accent" />
              <ActionButton label="强制更新" />
              <ActionButton label="导出安装包" icon={Download} />
            </div>
          </div>
        </Panel>

        <Panel title="插件授权名单" description="仅授权品牌客户可使用插件，支持灰度发布与版本控制。">
          <CrudToolbar
            searchPlaceholder="搜索租户、插件版本或授权状态"
            filters={['全部租户', '授权状态', '版本状态']}
            right={<ActionButton label="批量授权" icon={Upload} tone="accent" />}
          />
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="pb-3 font-medium">租户</th>
                  <th className="pb-3 font-medium">插件版本</th>
                  <th className="pb-3 font-medium">授权状态</th>
                  <th className="pb-3 font-medium">灰度比例</th>
                  <th className="pb-3 font-medium">说明</th>
                </tr>
              </thead>
              <tbody>
                {pluginTenants.map((tenant) => (
                  <tr key={tenant.tenant} className="border-t border-white/10 text-slate-200">
                    <td className="py-4 pr-4 font-medium text-slate-50">{tenant.tenant}</td>
                    <td className="py-4 pr-4">{tenant.version}</td>
                    <td className="py-4 pr-4">
                      <StatusBadge label={tenant.status} tone={tenant.status === '已授权' ? 'success' : tenant.status === '灰度发布' ? 'warning' : 'neutral'} />
                    </td>
                    <td className="py-4 pr-4">{tenant.rollout}</td>
                    <td className="py-4 pr-4 text-slate-400">{tenant.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </div>
    );
  } else if (activeView === 'parse-logs') {
    workspace = (
      <Panel title="解析日志监控" description="按时间、品牌、解析状态筛选日志。失败日志会自动打标原因，并可触发重试。">
        <CrudToolbar
          searchPlaceholder="搜索用户 ID、品牌 ID、链接地址或失败原因"
          filters={['近 24 小时', '全部品牌', '成功 / 失败', '按耗时排序']}
          right={<ActionButton label="导出日志" icon={Upload} />}
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">请求时间</th>
                <th className="pb-3 font-medium">用户 ID</th>
                <th className="pb-3 font-medium">品牌 ID</th>
                <th className="pb-3 font-medium">链接地址</th>
                <th className="pb-3 font-medium">结果</th>
                <th className="pb-3 font-medium">耗时</th>
                <th className="pb-3 font-medium">调用 API</th>
                <th className="pb-3 font-medium">失败原因</th>
                <th className="pb-3 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {parseLogs.map((log) => (
                <tr key={`${log.time}-${log.userId}`} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4">{log.time}</td>
                  <td className="py-4 pr-4">{log.userId}</td>
                  <td className="py-4 pr-4">{log.brandId}</td>
                  <td className="py-4 pr-4 text-slate-400">{log.url}</td>
                  <td className="py-4 pr-4">
                    <StatusBadge label={log.result} tone={log.result === '成功' ? 'success' : 'warning'} />
                  </td>
                  <td className="py-4 pr-4">{log.latency}</td>
                  <td className="py-4 pr-4 text-slate-400">{log.api}</td>
                  <td className="py-4 pr-4 text-slate-400">{log.reason}</td>
                  <td className="py-4">
                    <div className="flex flex-wrap gap-2">
                      <ActionButton label="重试" icon={RefreshCcw} className="px-3" />
                      <ActionButton label="查看明细" icon={Download} className="px-3" />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  } else if (activeView === 'clean-rules') {
    workspace = (
      <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <Panel title="数据清洗规则" description="对解析数据做冗余去除、核心文案提取与结构字段映射，保证前台分析结果一致。">
          <CrudToolbar
            searchPlaceholder="搜索清洗规则、字段目标或输出结果"
            filters={['启用中', '草稿', '字段映射']}
            right={<ActionButton label="新增规则" tone="accent" />}
          />
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="pb-3 font-medium">规则名称</th>
                  <th className="pb-3 font-medium">目标字段</th>
                  <th className="pb-3 font-medium">输出结果</th>
                  <th className="pb-3 font-medium">状态</th>
                </tr>
              </thead>
              <tbody>
                {cleaningRules.map((rule) => (
                <tr key={rule.rule} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{rule.rule}</td>
                  <td className="py-4 pr-4 text-slate-400">{rule.target}</td>
                  <td className="py-4 pr-4 text-slate-400">{rule.output}</td>
                    <td className="py-4 pr-4">
                      <StatusBadge label={rule.status} tone={rule.status === '启用' ? 'success' : 'neutral'} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        <Panel title="结构化字段映射" description="定义点赞、评论、收藏等结构化数据如何映射到统一解析层。">
          <div className="space-y-3">
            {[
              ['点赞数', 'like_count', '抖音 / 小红书'],
              ['评论数', 'comment_count', '抖音 / 小红书'],
              ['收藏数', 'favorite_count', '抖音 / 小红书'],
              ['分享数', 'share_count', '抖音'],
              ['账号名称', 'author_name', '全平台'],
              ['视频描述', 'video_description', '全平台'],
            ].map(([label, key, source]) => (
              <div key={label} className="grid gap-3 rounded-[20px] border border-white/10 bg-white/[0.03] p-4 sm:grid-cols-[1fr_1fr_140px]">
                <div>
                  <div className="text-sm font-medium text-slate-50">{label}</div>
                  <div className="mt-1 text-xs text-slate-500">来源平台：{source}</div>
                </div>
                <div className="rounded-xl border border-white/10 bg-black/20 px-3 py-3 text-sm text-slate-300">映射字段：{key}</div>
                <div className="flex items-center justify-start sm:justify-end">
                  <StatusBadge label="已映射" tone="success" />
                </div>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 01"
        title="数据采集与解析管理"
        description="聚焦后台需求文档里的基础 API 配置、浏览器插件、解析日志和数据清洗规则。该模块优先服务前台步骤 3 的爆款复刻能力。"
        tags={[
          { label: 'MVP 优先', tone: 'accent' },
          { label: '仅超级管理员 / 技术运维', tone: 'warning' },
        ]}
        action={<ActionButton label="新增解析服务商" tone="accent" />}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="在线解析服务" value="4" detail="抖音、小红书主备服务与统一解析网关均已纳管。" tone="accent" />
        <MetricCard label="解析成功率" value="98.2%" detail="过去 24 小时失败请求 31 次，主要来自授权过期。" tone="success" />
        <MetricCard label="平均耗时" value="1.6s" detail="高峰时段自动切换至备用 API 保障可用性。" tone="neutral" />
        <MetricCard label="待处理失败日志" value="12" detail="包含 5 条授权问题、4 条链接无效、3 条服务波动。" tone="warning" />
      </div>

      <SectionTabs items={sectionItems} activeItem={activeView} onChange={onViewChange} />

      {workspace}
    </div>
  );
}
