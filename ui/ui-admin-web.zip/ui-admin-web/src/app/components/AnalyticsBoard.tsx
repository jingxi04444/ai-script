import { BarChart3, CheckCircle2, LineChart, Sparkles } from 'lucide-react';
import { ActionButton, MetricCard, PageHeader, Panel, SectionTabs, StatusBadge } from './shared';

const sectionItems = [
  { id: 'data-screen', label: '数据大屏' },
  { id: 'trend-analysis', label: '趋势分析' },
  { id: 'ab-report', label: 'A/B 报告' },
];

const weeklyHotStructures = [
  { name: '痛点反问 + 使用前后对比', score: '92', note: '快消与家居类转化表现更强' },
  { name: '真实场景切入 + 产品演示 + CTA', score: '88', note: '适合短平快带货场景' },
  { name: '教程拆解 + 卖点插入 + 结尾福利', score: '83', note: '小红书和视频号表现稳定' },
];

export default function AnalyticsBoard({ activeView, onViewChange }: { activeView: string; onViewChange: (view: string) => void }) {
  let workspace = (
    <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
      <Panel title="数据大屏预览" description="为未来的全局与品牌数据展示预留大屏结构。">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
            <div className="flex items-center gap-3 text-slate-50">
              <LineChart className="h-5 w-5 text-[#22c55e]" />
              近 24 小时趋势
            </div>
            <div className="mt-5 flex h-40 items-end gap-2">
              {[48, 62, 57, 70, 76, 68, 88, 92].map((height, index) => (
                  <div key={height + index} className="flex-1 rounded-t-xl bg-gradient-to-t from-[#22c55e]/85 to-[#22c55e]/20" style={{ height: `${height}%` }} />
                ))}
              </div>
            </div>
          <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
            <div className="flex items-center gap-3 text-slate-50">
              <BarChart3 className="h-5 w-5 text-sky-300" />
              品牌分布
            </div>
            <div className="mt-5 space-y-4 text-sm text-slate-300">
              {[
                ['泊其品牌', '38%'],
                ['Nova 厨电', '27%'],
                ['Luma 个护', '18%'],
                ['其他品牌', '17%'],
              ].map(([label, value]) => (
                <div key={label} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>{label}</span>
                    <span className="text-slate-500">{value}</span>
                  </div>
                  <div className="h-2 rounded-full bg-white/5">
                    <div className="h-2 rounded-full bg-sky-400" style={{ width: value }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Panel>

      <Panel title="行业结构洞察" description="基于第三方数据统计的结构公式热度趋势。">
        <div className="space-y-4">
          {weeklyHotStructures.map((item) => (
            <div key={item.name} className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-base font-semibold text-slate-50">{item.name}</div>
                  <div className="mt-2 text-sm text-slate-400">{item.note}</div>
                </div>
                <StatusBadge label={`热度 ${item.score}`} tone="accent" />
              </div>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );

  if (activeView === 'trend-analysis') {
    workspace = (
      <Panel title="趋势分析视图" description="未来可按品牌、平台和卖点维度输出趋势数据。当前先提供信息架构和可视化排版参考。">
        <div className="grid gap-4 md:grid-cols-3">
          {weeklyHotStructures.map((item) => (
            <div key={item.name} className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="text-sm font-semibold text-slate-50">{item.name}</div>
              <div className="mt-3 text-3xl font-semibold text-[#bbf7d0]">{item.score}</div>
              <p className="mt-2 text-sm leading-6 text-slate-400">{item.note}</p>
            </div>
          ))}
        </div>
      </Panel>
    );
  } else if (activeView === 'ab-report') {
    workspace = (
      <Panel title="A/B 测试报告预留位" description="同一产品不同脚本版本的投放结果可在这里自动对比，并标记胜出原因。">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { version: 'A 版本', result: '播放高', note: '开头痛点更强，3 秒留存更好' },
            { version: 'B 版本', result: '转化高', note: '评论区引导更明确，福利口径更集中' },
            { version: 'C 版本', result: '互动高', note: '人物出镜更强，情绪张力更充足' },
          ].map((item) => (
            <div key={item.version} className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-2 text-slate-50">
                <Sparkles className="h-4 w-4 text-[#22c55e]" />
                {item.version}
              </div>
              <div className="mt-3 flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#22c55e]" />
                <span className="text-sm text-slate-300">{item.result}</span>
              </div>
              <p className="mt-3 text-sm leading-6 text-slate-400">{item.note}</p>
            </div>
          ))}
        </div>
      </Panel>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 05"
        title="投放数据看板"
        description="这是支撑前台步骤 9 的高阶模块。需求文档明确说明 MVP 暂不实现，因此当前后台 UI 先提供视觉化信息架构与未来扩展入口。"
        tags={[
          { label: '高阶规划', tone: 'warning' },
          { label: 'MVP 暂不实现', tone: 'neutral' },
        ]}
        action={<ActionButton label="生成趋势快照" tone="accent" />}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="全局播放量" value="1280 万" detail="未来将聚合所有品牌脚本投放结果并输出全局趋势。" tone="accent" />
        <MetricCard label="总互动率" value="9.4%" detail="点赞、评论、收藏、分享会统一折算为核心互动指标。" tone="success" />
        <MetricCard label="总转化订单数" value="3,218" detail="后续接入监测链接与第三方数据回传后可自动汇总。" tone="neutral" />
        <MetricCard label="平均 ROI" value="2.8" detail="品牌管理员可单独查看本品牌投放表现与历史趋势。" tone="warning" />
      </div>

      <SectionTabs items={sectionItems} activeItem={activeView} onChange={onViewChange} />

      {workspace}
    </div>
  );
}
