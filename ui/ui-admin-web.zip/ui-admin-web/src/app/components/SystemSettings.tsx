import { Activity, Bell, Building2, KeyRound, Lock, Search, Server, Users } from 'lucide-react';
import { ActionButton, CrudToolbar, MetricCard, PageHeader, Panel, ProgressRow, SectionTabs, StatusBadge } from './shared';

const sectionItems = [
  { id: 'tenant-config', label: '租户配置' },
  { id: 'api-config', label: 'API 管理' },
  { id: 'user-permissions', label: '用户权限' },
  { id: 'audit-monitor', label: '日志监控' },
];

const tenants = [
  { name: '泊其品牌', contact: '张晴', channel: '企业版 12 个月', domain: 'boqi.admin.local', status: '已启用' },
  { name: 'Nova 厨电', contact: '周维', channel: '企业版 6 个月', domain: 'nova.admin.local', status: '已启用' },
  { name: 'Luma 个护', contact: '何舟', channel: '试用中', domain: 'luma.admin.local', status: '待审核' },
];

const apiConnections = [
  { name: 'Claude 文生文', type: 'AI 模型 API', billing: '按 tokens', status: '启用', metric: '成功率 99.3%' },
  { name: 'Runway 视频生成', type: 'AI 模型 API', billing: '按秒计费', status: '启用', metric: '平均耗时 36s' },
  { name: '抖音开放平台', type: '第三方平台 API', billing: '授权接入', status: '待刷新', metric: '2 个 token 即将过期' },
  { name: '小红书解析授权', type: '第三方平台 API', billing: '授权接入', status: '启用', metric: '成功率 97.8%' },
];

const users = [
  { name: '林策', role: '系统超级管理员', scope: '全局', login: '账号密码 + MFA', status: '启用' },
  { name: '王乔', role: '品牌管理员', scope: '泊其品牌', login: '账号密码', status: '启用' },
  { name: '李墨', role: '审核员', scope: 'Nova 厨电', login: '手机号验证码', status: '启用' },
];

const logs = [
  { actor: '林策', action: '修改 API 阈值', time: '2026-04-20 09:30', ip: '10.10.12.28', detail: '将解析失败率告警阈值调整为 10%' },
  { actor: '系统', action: '触发内存告警', time: '2026-04-20 08:52', ip: '-', detail: '后台任务队列峰值过高，内存使用达到 82%' },
  { actor: '王乔', action: '导出审核记录', time: '2026-04-20 08:10', ip: '10.10.22.14', detail: '导出泊其品牌近 7 天审核报告' },
];

export default function SystemSettings({ activeView, onViewChange }: { activeView: string; onViewChange: (view: string) => void }) {
  let workspace = (
    <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
      <Panel title="多租户隔离配置" description="确保知识库、项目、素材和数据在数据库层面按品牌隔离。">
        <CrudToolbar
          searchPlaceholder="搜索品牌名称、联系人、专属域名或开通时长"
          filters={['全部租户', '已启用', '试用中']}
          right={<ActionButton label="新增品牌租户" tone="accent" />}
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">品牌租户</th>
                <th className="pb-3 font-medium">联系人</th>
                <th className="pb-3 font-medium">开通时长</th>
                <th className="pb-3 font-medium">专属域名</th>
                <th className="pb-3 font-medium">状态</th>
              </tr>
            </thead>
            <tbody>
              {tenants.map((tenant) => (
              <tr key={tenant.name} className="border-t border-white/10 text-slate-200">
                <td className="py-4 pr-4 font-medium text-slate-50">{tenant.name}</td>
                <td className="py-4 pr-4 text-slate-400">{tenant.contact}</td>
                  <td className="py-4 pr-4">{tenant.channel}</td>
                <td className="py-4 pr-4 text-slate-400">{tenant.domain}</td>
                  <td className="py-4 pr-4">
                    <StatusBadge label={tenant.status} tone={tenant.status === '已启用' ? 'success' : 'warning'} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <Panel title="系统监控与告警" description="监控服务器、数据库和 API 调用状态，按阈值触发邮件、短信或企业微信告警。">
        <div className="space-y-5">
          <ProgressRow label="CPU 使用率" value={43} caption="43%" tone="success" />
          <ProgressRow label="内存占用" value={82} caption="82%" tone="warning" />
          <ProgressRow label="磁盘占用" value={61} caption="61%" tone="accent" />
          <ProgressRow label="API 失败率" value={9} caption="9%" tone="neutral" />
        </div>
      </Panel>
    </div>
  );

  if (activeView === 'api-config') {
    workspace = (
      <Panel title="API 管理" description="统一管理 AI 模型与第三方平台授权，支撑链接解析、数据回传和一键发布。">
        <CrudToolbar
          searchPlaceholder="搜索 API 名称、类型、授权状态或计费方式"
          filters={['全部 API', 'AI 模型 API', '第三方平台 API', '待刷新']}
          right={<ActionButton label="新增 API 配置" tone="accent" />}
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">API 名称</th>
                <th className="pb-3 font-medium">类型</th>
                <th className="pb-3 font-medium">计费方式</th>
                <th className="pb-3 font-medium">状态</th>
                <th className="pb-3 font-medium">运行指标</th>
              </tr>
            </thead>
            <tbody>
              {apiConnections.map((connection) => (
                <tr key={connection.name} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{connection.name}</td>
                  <td className="py-4 pr-4">{connection.type}</td>
                  <td className="py-4 pr-4 text-slate-400">{connection.billing}</td>
                  <td className="py-4 pr-4">
                    <StatusBadge label={connection.status} tone={connection.status === '启用' ? 'success' : 'warning'} />
                  </td>
                  <td className="py-4 pr-4 text-slate-400">{connection.metric}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  } else if (activeView === 'user-permissions') {
    workspace = (
      <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
        <Panel title="用户账号管理" description="新增、编辑、禁用用户账号，并绑定角色和租户范围。">
          <CrudToolbar
            searchPlaceholder="搜索用户姓名、角色、权限范围或登录方式"
            filters={['全部角色', '启用中', '账号密码 / 验证码']}
            right={<ActionButton label="新增用户账号" tone="accent" />}
          />
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="pb-3 font-medium">用户</th>
                  <th className="pb-3 font-medium">角色</th>
                  <th className="pb-3 font-medium">权限范围</th>
                  <th className="pb-3 font-medium">登录方式</th>
                  <th className="pb-3 font-medium">状态</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.name} className="border-t border-white/10 text-slate-200">
                    <td className="py-4 pr-4 font-medium text-slate-50">{user.name}</td>
                    <td className="py-4 pr-4">{user.role}</td>
                    <td className="py-4 pr-4 text-slate-400">{user.scope}</td>
                    <td className="py-4 pr-4 text-slate-400">{user.login}</td>
                    <td className="py-4 pr-4">
                      <StatusBadge label={user.status} tone="success" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        <Panel title="登录与角色权限" description="支持账号密码、手机号验证码登录，控制密码复杂度、登录超时和角色边界。">
          <div className="space-y-4">
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <Lock className="h-5 w-5 text-[#22c55e]" />
                登录策略
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-400">默认启用账号密码登录，超级管理员必须开启二次验证；登录超时时间 30 分钟。</p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <KeyRound className="h-5 w-5 text-amber-300" />
                角色权限粒度
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-400">按模块维度配置超级管理员、品牌管理员、审核员权限，并支持自定义角色组合。</p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <Users className="h-5 w-5 text-sky-300" />
                预设角色
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <StatusBadge label="超级管理员" tone="warning" />
                <StatusBadge label="品牌管理员" tone="accent" />
                <StatusBadge label="审核员" tone="neutral" />
              </div>
            </div>
          </div>
        </Panel>
      </div>
    );
  } else if (activeView === 'audit-monitor') {
    workspace = (
      <Panel title="操作日志与系统告警" description="所有关键操作都必须留痕且不可删除，支持检索和导出。">
        <CrudToolbar
          searchPlaceholder="搜索操作人、日志动作、IP 或告警详情"
          filters={['近 24 小时', '关键操作', '系统告警']}
          right={
            <div className="flex flex-wrap gap-2">
              <ActionButton label="配置告警方式" icon={Bell} />
              <ActionButton label="查看监控面板" icon={Activity} />
            </div>
          }
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">操作人</th>
                <th className="pb-3 font-medium">日志动作</th>
                <th className="pb-3 font-medium">时间</th>
                <th className="pb-3 font-medium">IP</th>
                <th className="pb-3 font-medium">详情</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log) => (
                <tr key={`${log.actor}-${log.time}`} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{log.actor}</td>
                  <td className="py-4 pr-4">
                    <StatusBadge label={log.action} tone={log.action.includes('告警') ? 'warning' : 'neutral'} />
                  </td>
                  <td className="py-4 pr-4">{log.time}</td>
                  <td className="py-4 pr-4 text-slate-400">{log.ip}</td>
                  <td className="py-4 pr-4 text-slate-400">{log.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 06"
        title="系统与权限管理"
        description="多租户、外部 API、用户角色、登录策略、操作日志和系统监控都在这里统一配置，是后台最关键的安全与稳定基座。"
        tags={[
          { label: 'MVP 优先', tone: 'accent' },
          { label: '仅系统超级管理员', tone: 'warning' },
        ]}
        action={<ActionButton label="新增品牌租户" tone="accent" />}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="租户数量" value="18" detail="支持新增、编辑、禁用品牌租户，并配置专属域名和品牌信息。" tone="accent" />
        <MetricCard label="外部 API 接入" value="12" detail="覆盖文生文、文生图、文生视频、TTS、数字人和平台 API。" tone="success" />
        <MetricCard label="用户账号" value="74" detail="预设超级管理员、品牌管理员、审核员，并支持自定义角色。" tone="neutral" />
        <MetricCard label="关键告警" value="5" detail="包括服务器资源、数据库和 API 失败率阈值告警。" tone="warning" />
      </div>

      <SectionTabs items={sectionItems} activeItem={activeView} onChange={onViewChange} />

      {workspace}
    </div>
  );
}
