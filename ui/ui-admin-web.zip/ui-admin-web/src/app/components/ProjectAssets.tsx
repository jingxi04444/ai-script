import { Archive, Download, FolderOpen, HardDrive, Tags } from 'lucide-react';
import { ActionButton, CrudToolbar, MetricCard, PageHeader, Panel, ProgressRow, SectionTabs, StatusBadge } from './shared';

const sectionItems = [
  { id: 'projects', label: '项目库' },
  { id: 'materials', label: '素材库' },
  { id: 'storage', label: '存储管理' },
  { id: 'reuse-report', label: '复用报告' },
];

const projects = [
  { id: 'PRJ-1182', brand: '泊其品牌', status: '生成中', creator: '陈一', product: '便携加热饭盒', assets: 12, createdAt: '2026-04-20 09:18' },
  { id: 'PRJ-1176', brand: 'Nova 厨电', status: '审核中', creator: '宋舟', product: '胶囊咖啡机', assets: 8, createdAt: '2026-04-20 08:42' },
  { id: 'PRJ-1168', brand: 'Luma 个护', status: '已归档', creator: '赵宁', product: '发膜护理套组', assets: 19, createdAt: '2026-04-19 18:05' },
];

const assets = [
  { name: '镜号03-办公室热饭.mp4', type: '视频片段', tag: '产品特写', usage: '7 次', path: '/tenant/br018/projects/prj1182/video/03.mp4' },
  { name: '旁白-女声-v2.wav', type: '配音', tag: '温柔语气', usage: '4 次', path: '/tenant/br018/projects/prj1182/audio/narration-v2.wav' },
  { name: '办公室参考图-01.png', type: '场景图', tag: '办公场景', usage: '11 次', path: '/tenant/br018/library/scene/office-01.png' },
];

const storagePolicies = [
  { brand: '泊其品牌', used: 72, caption: '1.8TB / 2.5TB', rule: '超出阈值发送品牌管理员提醒' },
  { brand: 'Nova 厨电', used: 54, caption: '1.1TB / 2.0TB', rule: '达到 80% 自动建议清理低质量素材' },
  { brand: 'Luma 个护', used: 88, caption: '1.76TB / 2.0TB', rule: '已接近上限，建议归档 30 天未使用素材' },
];

const reuseRows = [
  { asset: '产品特写-办公场景-01', type: '视频片段', reuse: '16 次', effect: '转化率提升 11%', note: '适合办公便携类产品' },
  { asset: '旁白-温柔女声-v2', type: '配音', reuse: '9 次', effect: '互动率提升 6%', note: '适合生活方式类脚本' },
  { asset: '办公室参考图-01', type: '场景图', reuse: '11 次', effect: '留存提升 4%', note: '适合白领工作场景' },
];

export default function ProjectAssets({ activeView, onViewChange }: { activeView: string; onViewChange: (view: string) => void }) {
  let workspace = (
    <Panel title="项目库管理" description="展示后台项目状态、关联产品和素材数量，支持按品牌、状态、时间筛选。">
      <CrudToolbar
        searchPlaceholder="搜索项目 ID、品牌、创建人或关联产品"
        filters={['全部品牌', '项目状态', '最近创建']}
        right={
          <div className="flex flex-wrap gap-2">
            <ActionButton label="新建项目归档" tone="accent" />
            <ActionButton label="导出项目列表" />
          </div>
        }
      />
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="text-slate-500">
            <tr>
              <th className="pb-3 font-medium">项目 ID</th>
              <th className="pb-3 font-medium">品牌</th>
              <th className="pb-3 font-medium">状态</th>
              <th className="pb-3 font-medium">创建人</th>
              <th className="pb-3 font-medium">关联产品</th>
              <th className="pb-3 font-medium">素材数量</th>
              <th className="pb-3 font-medium">创建时间</th>
            </tr>
          </thead>
          <tbody>
            {projects.map((project) => (
              <tr key={project.id} className="border-t border-white/10 text-slate-200">
                <td className="py-4 pr-4 font-medium text-slate-50">{project.id}</td>
                <td className="py-4 pr-4">{project.brand}</td>
                <td className="py-4 pr-4">
                  <StatusBadge label={project.status} tone={project.status === '已归档' ? 'neutral' : project.status === '生成中' ? 'accent' : 'warning'} />
                </td>
                <td className="py-4 pr-4 text-slate-400">{project.creator}</td>
                <td className="py-4 pr-4 text-slate-400">{project.product}</td>
                <td className="py-4 pr-4">{project.assets}</td>
                <td className="py-4">{project.createdAt}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );

  if (activeView === 'materials') {
    workspace = (
      <Panel title="素材库管理" description="查看素材详情、标签、使用次数、存储路径，并执行预览、下载、批量导出等操作。">
        <CrudToolbar
          searchPlaceholder="搜索素材名称、标签、路径或素材类型"
          filters={['全部素材', '视频片段', '配音', '场景图']}
          right={<ActionButton label="批量导出素材" icon={Download} />}
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">素材名称</th>
                <th className="pb-3 font-medium">类型</th>
                <th className="pb-3 font-medium">标签</th>
                <th className="pb-3 font-medium">复用次数</th>
                <th className="pb-3 font-medium">存储路径</th>
                <th className="pb-3 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {assets.map((asset) => (
                <tr key={asset.name} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{asset.name}</td>
                  <td className="py-4 pr-4">{asset.type}</td>
                  <td className="py-4 pr-4">
                    <StatusBadge label={asset.tag} tone="neutral" />
                  </td>
                  <td className="py-4 pr-4">{asset.usage}</td>
                  <td className="py-4 pr-4 text-slate-400">{asset.path}</td>
                  <td className="py-4">
                    <div className="flex flex-wrap gap-2">
                      <ActionButton label="预览" icon={FolderOpen} className="px-3" />
                      <ActionButton label="下载" icon={Download} className="px-3" />
                      <ActionButton label="归档" icon={Archive} className="px-3" />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  } else if (activeView === 'storage') {
    workspace = (
      <Panel title="存储管理" description="查看品牌素材占用、存储上限和清理建议。">
        <div className="space-y-5">
          {storagePolicies.map((policy) => (
            <div key={policy.brand} className="rounded-[22px] border border-white/10 bg-white/[0.03] p-5">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <div className="text-base font-semibold text-slate-50">{policy.brand}</div>
                  <div className="mt-1 text-sm text-slate-500">{policy.rule}</div>
                </div>
                <StatusBadge label={policy.caption} tone={policy.used >= 80 ? 'warning' : 'success'} />
              </div>
              <div className="mt-4">
                <ProgressRow label="存储占用" value={policy.used} caption={policy.caption} tone={policy.used >= 80 ? 'warning' : 'accent'} />
              </div>
            </div>
          ))}
          <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4 text-sm leading-6 text-slate-400">
            当品牌存储超过设定上限时，可提醒品牌管理员清理低质量素材或申请扩容。超级管理员可查看全局存储统计。
          </div>
        </div>
      </Panel>
    );
  } else if (activeView === 'reuse-report') {
    workspace = (
      <Panel title="素材复用统计" description="支持按素材类型、标签、复用率筛选，输出高复用与低质量素材报告。">
        <CrudToolbar
          searchPlaceholder="搜索素材名称、标签、复用效果或报告结论"
          filters={['高复用素材', '低质量素材', '按复用率排序']}
          right={<ActionButton label="生成复用报告" tone="accent" />}
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">素材名称</th>
                <th className="pb-3 font-medium">素材类型</th>
                <th className="pb-3 font-medium">复用次数</th>
                <th className="pb-3 font-medium">复用效果</th>
                <th className="pb-3 font-medium">结论</th>
              </tr>
            </thead>
            <tbody>
              {reuseRows.map((row) => (
                <tr key={row.asset} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{row.asset}</td>
                  <td className="py-4 pr-4">{row.type}</td>
                  <td className="py-4 pr-4">{row.reuse}</td>
                  <td className="py-4 pr-4 text-slate-400">{row.effect}</td>
                  <td className="py-4 pr-4 text-slate-400">{row.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 04"
        title="视频素材与项目库管理"
        description="用于承接前台步骤 6 到 8 的项目、素材与复用统计。该模块不在当前后台 MVP 必做清单中，但已按需求文档提供管理界面骨架。"
        tags={[
          { label: '扩展模块', tone: 'neutral' },
          { label: '品牌隔离存储', tone: 'accent' },
        ]}
        action={<ActionButton label="新建项目归档" tone="accent" />}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="后台项目总数" value="312" detail="记录前台脚本任务在后台的项目状态与素材数量。" tone="accent" />
        <MetricCard label="在线素材数" value="4,860" detail="视频片段、配音、场景图和参考素材统一纳管。" tone="success" />
        <MetricCard label="存储占用" value="6.2TB" detail="按品牌统计使用量并支持设置上限提醒。" tone="warning" />
        <MetricCard label="高复用素材" value="128" detail="可生成高复用素材 Top10 和低质量素材 Top10 报告。" tone="neutral" />
      </div>

      <SectionTabs items={sectionItems} activeItem={activeView} onChange={onViewChange} />

      {workspace}
    </div>
  );
}
