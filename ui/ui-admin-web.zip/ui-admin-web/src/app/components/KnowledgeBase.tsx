import { BookOpen, Database, FileText, Search, Tags } from 'lucide-react';
import { ActionButton, CrudToolbar, MetricCard, PageHeader, Panel, SectionTabs, StatusBadge } from './shared';

const sectionItems = [
  { id: 'formula-library', label: '结构公式' },
  { id: 'selling-points', label: '卖点知识' },
  { id: 'compliance-dictionary', label: '合规词库' },
  { id: 'tag-system', label: '标签体系' },
];

const formulas = [
  {
    name: '3 秒痛点切入 + 场景放大 + 产品解决 + 评论区引导',
    type: '剧情口播',
    platform: '抖音',
    usage: '38 次',
    note: '适用于快消品、办公便携类产品',
  },
  {
    name: '问题反问 + 真实对比 + 功能展开 + 福利收口',
    type: '产品展示',
    platform: '小红书',
    usage: '21 次',
    note: '适合种草型产品与生活场景表达',
  },
];

const sellingPoints = [
  { product: '宠鲜鲜智能加热饭盒', brand: '泊其品牌', mainPoint: '20 分钟快速加热', tags: '核心卖点 / 办公场景', updatedAt: '2026-04-20 09:12' },
  { product: 'Nova 胶囊咖啡机', brand: 'Nova 厨电', mainPoint: '一键萃取 30 秒出杯', tags: '核心卖点 / 厨房场景', updatedAt: '2026-04-19 18:24' },
  { product: 'Luma 发膜护理套组', brand: 'Luma 个护', mainPoint: '三步修护毛躁干枯', tags: '辅助卖点 / 居家护理', updatedAt: '2026-04-19 16:45' },
];

const complianceWords = [
  { word: '最', category: '广告法违禁词', suggestion: '更适合 / 更有优势', source: '公共词库', status: '启用' },
  { word: '第一', category: '广告法违禁词', suggestion: '领先 / 更受欢迎', source: '公共词库', status: '启用' },
  { word: '国家级', category: '广告法违禁词', suggestion: '专业标准', source: '公共词库', status: '启用' },
  { word: '独家秘方', category: '行业敏感词', suggestion: '自研方案', source: '行业敏感词库', status: '启用' },
];

const tagRules = [
  { tag: '产品特写', type: '景别标签', relation: '自动关联主卖点', usage: '142 次', status: '启用' },
  { tag: '情绪爆发', type: '情绪标签', relation: '关联高冲突剧情镜头', usage: '56 次', status: '启用' },
  { tag: '办公场景', type: '场景标签', relation: '适配白领、加班人群', usage: '88 次', status: '启用' },
  { tag: '品牌自定义-奶油感', type: '品牌标签', relation: '等待管理员审核上线', usage: '0 次', status: '待审核' },
];

export default function KnowledgeBase({
  tenantLabel,
  activeView,
  onViewChange,
}: {
  tenantLabel: string;
  activeView: string;
  onViewChange: (view: string) => void;
}) {
  let workspace = (
    <Panel title="结构公式库" description="同步前台步骤 3 的分析结果，支持手动录入、编辑、删除、适用场景标注和复用次数统计。">
      <CrudToolbar
        searchPlaceholder="搜索公式名称、平台、视频类型或适用场景"
        filters={['全部平台', '视频类型', '复用次数排序']}
        right={
          <div className="flex flex-wrap gap-2">
            <ActionButton label="新增结构公式" tone="accent" />
            <ActionButton label="导出公式库" />
          </div>
        }
      />
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="text-slate-500">
            <tr>
              <th className="pb-3 font-medium">公式名称</th>
              <th className="pb-3 font-medium">视频类型</th>
              <th className="pb-3 font-medium">投放平台</th>
              <th className="pb-3 font-medium">复用次数</th>
              <th className="pb-3 font-medium">适用场景说明</th>
              <th className="pb-3 font-medium">操作</th>
            </tr>
          </thead>
          <tbody>
            {formulas.map((formula) => (
              <tr key={formula.name} className="border-t border-white/10 text-slate-200">
                <td className="py-4 pr-4 font-medium text-slate-50">{formula.name}</td>
                <td className="py-4 pr-4">{formula.type}</td>
                <td className="py-4 pr-4 text-slate-400">{formula.platform}</td>
                <td className="py-4 pr-4">{formula.usage}</td>
                <td className="py-4 pr-4 text-slate-400">{formula.note}</td>
                <td className="py-4">
                  <div className="flex flex-wrap gap-2">
                    <ActionButton label="编辑" className="px-3" />
                    <ActionButton label="查看复用" className="px-3" />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );

  if (activeView === 'selling-points') {
    workspace = (
      <Panel title="产品卖点知识库" description="保存标准化卖点信息、标签和版本记录，支持 CSV 批量导入导出与按品牌检索。">
        <CrudToolbar
          searchPlaceholder="搜索产品名称、品牌、主卖点或更新时间"
          filters={['全部品牌', '主卖点 / 辅助卖点', '最近更新']}
          right={
            <div className="flex flex-wrap gap-2">
              <ActionButton label="批量导入 CSV" tone="accent" />
              <ActionButton label="导出卖点数据" />
            </div>
          }
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">产品名称</th>
                <th className="pb-3 font-medium">品牌</th>
                <th className="pb-3 font-medium">主卖点</th>
                <th className="pb-3 font-medium">标签</th>
                <th className="pb-3 font-medium">更新时间</th>
              </tr>
            </thead>
            <tbody>
              {sellingPoints.map((row) => (
              <tr key={`${row.brand}-${row.product}`} className="border-t border-white/10 text-slate-200">
                <td className="py-4 pr-4 font-medium text-slate-50">{row.product}</td>
                  <td className="py-4 pr-4">{row.brand}</td>
                <td className="py-4 pr-4 text-slate-400">{row.mainPoint}</td>
                <td className="py-4 pr-4 text-slate-400">{row.tags}</td>
                  <td className="py-4 pr-4">{row.updatedAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  } else if (activeView === 'compliance-dictionary') {
    workspace = (
      <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
        <Panel title="合规词库" description="内置广告法违禁词、行业敏感词与替换建议，支撑前台步骤 4 的合规校验。">
          <CrudToolbar
            searchPlaceholder="搜索违禁词、分类、替换建议或词库来源"
            filters={['广告法违禁词', '行业敏感词', '启用中']}
            right={<ActionButton label="新增词条" tone="accent" />}
          />
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="pb-3 font-medium">违禁词</th>
                  <th className="pb-3 font-medium">分类</th>
                  <th className="pb-3 font-medium">替换建议</th>
                  <th className="pb-3 font-medium">词库来源</th>
                  <th className="pb-3 font-medium">状态</th>
                </tr>
              </thead>
              <tbody>
                {complianceWords.map((item) => (
                <tr key={item.word} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{item.word}</td>
                    <td className="py-4 pr-4">{item.category}</td>
                  <td className="py-4 pr-4 text-slate-400">{item.suggestion}</td>
                  <td className="py-4 pr-4 text-slate-400">{item.source}</td>
                    <td className="py-4 pr-4">
                      <StatusBadge label={item.status} tone="success" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        <Panel title="公共资源库概览" description="提供全品牌共享的通用结构公式、场景 / 角色资源和合规能力。">
          <div className="space-y-4">
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <BookOpen className="h-5 w-5 text-[#22c55e]" />
                通用结构公式库
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-400">跨品牌适用的通用爆款结构，品牌管理员可按需导入到私有公式库。</p>
            </div>
            <div className="rounded-[22px] border border-amber-400/20 bg-amber-400/10 p-4">
              <div className="flex items-center gap-3 text-amber-100">
                <Search className="h-5 w-5" />
                替换建议库
              </div>
              <p className="mt-2 text-sm leading-6 text-amber-50/85">为高风险词条配置标准化替换方案，避免审核阶段重复人工解释。</p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <Database className="h-5 w-5 text-sky-300" />
                场景 / 角色库
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-400">为前台视觉配置提供通用场景、角色和道具资源，支持审核后上线。</p>
            </div>
          </div>
        </Panel>
      </div>
    );
  } else if (activeView === 'tag-system') {
    workspace = (
      <Panel title="素材标签体系" description="管理标签类别、关联规则与品牌自定义标签审核。">
        <CrudToolbar
          searchPlaceholder="搜索标签名称、分类、关联规则或使用频率"
          filters={['全部标签', '景别类型', '情绪标签', '品牌自定义']}
          right={<ActionButton label="新增标签" tone="accent" />}
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">标签名称</th>
                <th className="pb-3 font-medium">标签类型</th>
                <th className="pb-3 font-medium">关联规则</th>
                <th className="pb-3 font-medium">使用频率</th>
                <th className="pb-3 font-medium">状态</th>
              </tr>
            </thead>
            <tbody>
              {tagRules.map((rule) => (
                <tr key={rule.tag} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{rule.tag}</td>
                  <td className="py-4 pr-4">{rule.type}</td>
                  <td className="py-4 pr-4 text-slate-400">{rule.relation}</td>
                  <td className="py-4 pr-4">{rule.usage}</td>
                  <td className="py-4 pr-4">
                    <StatusBadge label={rule.status} tone={rule.status === '启用' ? 'success' : 'warning'} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 02"
        title="知识库管理"
        description="管理品牌私有知识库与公共资源库，支撑 AI 生成脚本的精准性、复用性与合规性。当前重点覆盖品牌私有结构公式库和基础合规词库。"
        tags={[
          { label: `当前租户：${tenantLabel}`, tone: 'neutral' },
          { label: '品牌隔离', tone: 'accent' },
          { label: 'MVP 优先', tone: 'accent' },
        ]}
        action={<ActionButton label="新增结构公式" tone="accent" />}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="私有结构公式" value="42" detail="按品牌隔离沉淀，仅存储结构特征与适用场景说明。" tone="accent" />
        <MetricCard label="卖点知识条目" value="136" detail="自动同步前台卖点输入，支持回退和批量导入导出。" tone="success" />
        <MetricCard label="素材标签规则" value="58" detail="覆盖景别、情绪、展示方式等分类及关联规则。" tone="neutral" />
        <MetricCard label="合规词库" value="326" detail="广告法违禁词与行业敏感词统一纳管，并配置替换建议。" tone="warning" />
      </div>

      <SectionTabs items={sectionItems} activeItem={activeView} onChange={onViewChange} />

      {workspace}
    </div>
  );
}
