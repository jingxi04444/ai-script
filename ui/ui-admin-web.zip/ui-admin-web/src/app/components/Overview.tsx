import { AlertTriangle, Building2, CheckCircle2, Database, Shield, Users } from 'lucide-react';
import { ActionButton, MetricCard, PageHeader, Panel, ProgressRow, SectionTabs, StatusBadge } from './shared';

const sectionItems = [
  { id: 'dashboard', label: '平台看板' },
  { id: 'tenant-risk', label: '租户态势' },
  { id: 'priority-actions', label: '优先动作' },
];

export default function Overview({
  roleLabel,
  tenantLabel,
  activeView,
  onViewChange,
}: {
  roleLabel: string;
  tenantLabel: string;
  activeView: string;
  onViewChange: (view: string) => void;
}) {
  const tenants = [
    { name: '泊其品牌', status: '隔离正常', scripts: '124', note: '结构公式库更新至 42 条' },
    { name: 'Nova 厨电', status: '审核中', scripts: '86', note: '昨日新增 18 条解析日志' },
    { name: 'Luma 个护', status: '监控正常', scripts: '57', note: '素材复用率较上周提升 12%' },
  ];

  const actionQueue = [
    { item: '解析失败重试队列', owner: '技术运维', deadline: '今日 18:00', level: '高优先级' },
    { item: '新租户合规词库同步', owner: '系统超级管理员', deadline: '明日 10:00', level: '高优先级' },
    { item: '审核 SLA 周报导出', owner: '品牌管理员', deadline: '本周五', level: '常规' },
  ];

  let workspace = (
    <div className="grid gap-6 xl:grid-cols-[1.3fr_1fr]">
      <Panel title="后台能力覆盖" description="按需求文档拆分的六大模块，其中前四项和系统权限治理属于当前优先建设范围。">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-[24px] border border-white/10 bg-white/[0.03] p-4">
            <div className="flex items-center gap-3 text-slate-50">
              <Database className="h-5 w-5 text-[#22c55e]" />
              数据采集与解析管理
            </div>
            <p className="mt-3 text-sm leading-6 text-slate-400">管理爆款链接解析 API、浏览器插件、解析日志与数据清洗规则，支撑前台步骤 3 稳定运行。</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <StatusBadge label="MVP" tone="accent" />
              <StatusBadge label="运维可操作" tone="neutral" />
            </div>
          </div>
          <div className="rounded-[24px] border border-white/10 bg-white/[0.03] p-4">
            <div className="flex items-center gap-3 text-slate-50">
              <Shield className="h-5 w-5 text-sky-300" />
              知识库与合规管控
            </div>
            <p className="mt-3 text-sm leading-6 text-slate-400">覆盖品牌私有结构公式库、卖点库、标签体系与公共合规词库，构建内容复用与合规壁垒。</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <StatusBadge label="MVP" tone="accent" />
              <StatusBadge label="品牌隔离" tone="success" />
            </div>
          </div>
          <div className="rounded-[24px] border border-white/10 bg-white/[0.03] p-4">
            <div className="flex items-center gap-3 text-slate-50">
              <Users className="h-5 w-5 text-amber-300" />
              审核工作流管理
            </div>
            <p className="mt-3 text-sm leading-6 text-slate-400">支持审核席位、任务分配、规则配置和不可删除的审核轨迹，确保生成脚本可追溯。</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <StatusBadge label="MVP" tone="accent" />
              <StatusBadge label="单级审核" tone="neutral" />
            </div>
          </div>
          <div className="rounded-[24px] border border-white/10 bg-white/[0.03] p-4">
            <div className="flex items-center gap-3 text-slate-50">
              <Building2 className="h-5 w-5 text-emerald-300" />
              系统与权限管理
            </div>
            <p className="mt-3 text-sm leading-6 text-slate-400">聚焦品牌租户、外部 API、用户角色与系统日志，是整个后台的安全基座。</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <StatusBadge label="MVP" tone="accent" />
              <StatusBadge label="仅超级管理员" tone="warning" />
            </div>
          </div>
        </div>
      </Panel>

      <Panel title="风险优先级" description="合规、隔离和 API 稳定性是管理端最重要的三条线。">
        <div className="space-y-5">
          <ProgressRow label="多租户隔离完整度" value={94} caption="18/18 品牌已独立配置" tone="accent" />
          <ProgressRow label="审核任务 SLA 达成率" value={86} caption="平均 2.8 小时完成" tone="success" />
          <ProgressRow label="API 告警修复及时率" value={71} caption="近 7 天仍有 2 条积压" tone="warning" />
        </div>
        <div className="mt-6 rounded-[22px] border border-amber-400/20 bg-amber-400/10 p-4 text-sm leading-6 text-amber-100">
          当前最需要关注的风险是解析失败重试队列与新租户合规词库未同步，请优先在系统权限和数据采集模块内处理。
        </div>
      </Panel>
    </div>
  );

  if (activeView === 'tenant-risk') {
    workspace = (
      <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
        <Panel title="租户运行态势" description="品牌租户必须独立存储、互不可见，并保留可追踪操作轨迹。">
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="pb-3 font-medium">品牌租户</th>
                  <th className="pb-3 font-medium">隔离状态</th>
                  <th className="pb-3 font-medium">近 7 天脚本任务</th>
                  <th className="pb-3 font-medium">运行备注</th>
                </tr>
              </thead>
              <tbody>
                {tenants.map((tenant) => (
                  <tr key={tenant.name} className="border-t border-white/10 text-slate-200">
                    <td className="py-4 pr-4 font-medium text-slate-50">{tenant.name}</td>
                    <td className="py-4 pr-4">
                      <StatusBadge label={tenant.status} tone={tenant.status === '审核中' ? 'warning' : 'success'} />
                    </td>
                    <td className="py-4 pr-4">{tenant.scripts}</td>
                    <td className="py-4 pr-4 text-slate-400">{tenant.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        <Panel title="风险分布" description="按租户查看当前最需要处理的治理事项。">
          <div className="space-y-5">
            <ProgressRow label="泊其品牌" value={24} caption="低风险" tone="success" />
            <ProgressRow label="Nova 厨电" value={58} caption="中风险" tone="warning" />
            <ProgressRow label="Luma 个护" value={36} caption="关注" tone="accent" />
          </div>
        </Panel>
      </div>
    );
  } else if (activeView === 'priority-actions') {
    workspace = (
      <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
        <Panel title="优先动作清单" description="当前后台值班团队最需要跟进的治理动作。">
          <div className="space-y-4">
            {actionQueue.map((action) => (
              <div key={action.item} className="flex gap-3 rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
                {action.level === '高优先级' ? (
                  <AlertTriangle className="mt-0.5 h-5 w-5 flex-none text-amber-300" />
                ) : (
                  <CheckCircle2 className="mt-0.5 h-5 w-5 flex-none text-[#22c55e]" />
                )}
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                <div className="text-sm font-semibold text-slate-50">{action.item}</div>
                <StatusBadge label={action.level} tone={action.level === '高优先级' ? 'warning' : 'success'} />
              </div>
                  <div className="mt-2 text-sm text-slate-400">责任人：{action.owner} · 截止时间：{action.deadline}</div>
                </div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="处理建议" description="根据后台需求文档整理的当前运营重点。">
          <div className="space-y-4">
            <div className="flex gap-3 rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <CheckCircle2 className="mt-0.5 h-5 w-5 flex-none text-[#22c55e]" />
              <div>
                <div className="text-sm font-semibold text-slate-50">把解析日志和知识库同步链路打通</div>
                <p className="mt-2 text-sm leading-6 text-slate-400">确保前台步骤 2 与步骤 3 的信息能自动回流到后台结构公式库和卖点知识库中。</p>
              </div>
            </div>
            <div className="flex gap-3 rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <AlertTriangle className="mt-0.5 h-5 w-5 flex-none text-amber-300" />
              <div>
                <div className="text-sm font-semibold text-slate-50">优先做合规触发条件与审核记录留痕</div>
                <p className="mt-2 text-sm leading-6 text-slate-400">这部分直接决定前台脚本能否安全上线，也是管理端 MVP 的核心价值点。</p>
              </div>
            </div>
          </div>
        </Panel>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Admin Overview"
        title="后台治理总览"
        description="围绕多租户隔离、合规审核、解析稳定性与权限控制构建统一后台。当前界面覆盖管理端核心模块，并突出 MVP 优先能力。"
        tags={[
          { label: `角色视角：${roleLabel}`, tone: 'accent' },
          { label: `租户范围：${tenantLabel}`, tone: 'neutral' },
          { label: '后台需求文档驱动', tone: 'success' },
        ]}
        action={<ActionButton label="生成治理周报" tone="accent" />}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="活跃品牌租户" value="18" detail="多租户隔离已开启，品牌数据按知识库、项目、素材独立存储。" tone="accent" />
        <MetricCard label="待审核脚本" value="46" detail="单级审核工作流正在运行，超时任务会进入催审池。" tone="warning" />
        <MetricCard label="解析成功率" value="98.2%" detail="主备 API 已配置优先级切换，最近 24 小时平均耗时 1.6 秒。" tone="success" />
        <MetricCard label="关键风险告警" value="03" detail="涉及 1 条违禁词策略调整、2 条 API 阈值预警，需要管理员处理。" tone="warning" />
      </div>

      <SectionTabs items={sectionItems} activeItem={activeView} onChange={onViewChange} />

      {workspace}
    </div>
  );
}
