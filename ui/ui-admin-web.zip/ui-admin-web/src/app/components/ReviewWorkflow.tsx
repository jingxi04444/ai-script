import { CheckCircle2, Clock3, FileText, Shield, Users } from 'lucide-react';
import { ActionButton, CrudToolbar, MetricCard, PageHeader, Panel, SectionTabs, StatusBadge } from './shared';

const sectionItems = [
  { id: 'reviewers', label: '审核席位' },
  { id: 'tasks', label: '审核任务' },
  { id: 'rules', label: '审核规则' },
  { id: 'records', label: '审核记录' },
];

const reviewers = [
  { name: '周芷运营审核', role: '运营审核', brand: '泊其品牌', pending: 11, completed: 28, duration: '2.1h', status: '在线' },
  { name: '李墨法务审核', role: '法务审核', brand: 'Nova 厨电', pending: 8, completed: 17, duration: '3.4h', status: '在线' },
  { name: '王乔品牌审核', role: '品牌审核', brand: 'Luma 个护', pending: 6, completed: 25, duration: '1.8h', status: '在线' },
];

const tasks = [
  { id: 'SC-240420-018', brand: '泊其品牌', submitter: '陈一', stage: '待分配', status: '待审核', submittedAt: '09:22', note: '主卖点涉及保温功效，需要合规复核' },
  { id: 'SC-240420-015', brand: 'Nova 厨电', submitter: '宋舟', stage: '运营审核', status: '审核中', submittedAt: '08:54', note: '原创度接近阈值，需人工确认' },
  { id: 'SC-240420-012', brand: 'Luma 个护', submitter: '赵宁', stage: '已通过', status: '已完成', submittedAt: '08:11', note: '已同步审核记录与修改意见' },
];

const ruleRows = [
  { item: '违禁词高亮级别', value: '高', trigger: '命中广告法或行业敏感词库', notify: '系统消息' },
  { item: '原创度提醒阈值', value: '60%', trigger: '相似度超过阈值', notify: '系统消息 + 审核备注' },
  { item: '任务超时催审', value: '2 小时', trigger: '待审核任务未处理', notify: '站内提醒' },
  { item: '审核流程', value: '单级审核', trigger: 'MVP 默认配置', notify: '提交后进入审核池' },
];

const records = [
  { id: 'SC-240420-012', actor: '王乔', action: '审核通过', time: '08:42', detail: '建议保留第 3 镜 CTA，替换“唯一”表述。' },
  { id: 'SC-240420-015', actor: '系统', action: '催审提醒', time: '09:10', detail: '任务超过 2 小时未处理，已提醒品牌审核员。' },
  { id: 'SC-240420-018', actor: '系统', action: '任务入队', time: '09:22', detail: '新脚本已进入待审核池，等待分配审核员。' },
];

export default function ReviewWorkflow({ activeView, onViewChange }: { activeView: string; onViewChange: (view: string) => void }) {
  let workspace = (
    <Panel title="审核席位管理" description="为每个品牌分配审核员账号，查看工作负载与平均审核耗时。">
      <CrudToolbar
        searchPlaceholder="搜索审核员姓名、品牌或角色"
        filters={['全部品牌', '在线状态', '待审核数量']}
        right={<ActionButton label="新增审核员" tone="accent" />}
      />
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="text-slate-500">
            <tr>
              <th className="pb-3 font-medium">审核员</th>
              <th className="pb-3 font-medium">角色</th>
              <th className="pb-3 font-medium">品牌范围</th>
              <th className="pb-3 font-medium">待审核</th>
              <th className="pb-3 font-medium">已审核</th>
              <th className="pb-3 font-medium">平均耗时</th>
              <th className="pb-3 font-medium">状态</th>
            </tr>
          </thead>
          <tbody>
            {reviewers.map((reviewer) => (
              <tr key={reviewer.name} className="border-t border-white/10 text-slate-200">
                <td className="py-4 pr-4 font-medium text-slate-50">{reviewer.name}</td>
                <td className="py-4 pr-4">{reviewer.role}</td>
                <td className="py-4 pr-4 text-slate-400">{reviewer.brand}</td>
                <td className="py-4 pr-4">{reviewer.pending}</td>
                <td className="py-4 pr-4">{reviewer.completed}</td>
                <td className="py-4 pr-4">{reviewer.duration}</td>
                <td className="py-4 pr-4">
                  <StatusBadge label={reviewer.status} tone="success" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );

  if (activeView === 'tasks') {
    workspace = (
      <Panel title="审核任务管理" description="待审核列表支持筛选、分配、催审与查看修改说明。">
        <CrudToolbar
          searchPlaceholder="搜索脚本 ID、品牌、提交人或审核备注"
          filters={['全部品牌', '脚本状态', '审核阶段', '提交人']}
          right={
            <div className="flex flex-wrap gap-2">
              <ActionButton label="自动分配" tone="accent" />
              <ActionButton label="批量催审" />
            </div>
          }
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">脚本 ID</th>
                <th className="pb-3 font-medium">品牌</th>
                <th className="pb-3 font-medium">提交人</th>
                <th className="pb-3 font-medium">审核阶段</th>
                <th className="pb-3 font-medium">任务状态</th>
                <th className="pb-3 font-medium">提交时间</th>
                <th className="pb-3 font-medium">审核备注</th>
                <th className="pb-3 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map((task) => (
                <tr key={task.id} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{task.id}</td>
                  <td className="py-4 pr-4">{task.brand}</td>
                  <td className="py-4 pr-4 text-slate-400">{task.submitter}</td>
                  <td className="py-4 pr-4">{task.stage}</td>
                  <td className="py-4 pr-4">
                    <StatusBadge label={task.status} tone={task.status === '已完成' ? 'success' : task.status === '审核中' ? 'neutral' : 'warning'} />
                  </td>
                  <td className="py-4 pr-4">{task.submittedAt}</td>
                  <td className="py-4 pr-4 text-slate-400">{task.note}</td>
                  <td className="py-4">
                    <div className="flex flex-wrap gap-2">
                      <ActionButton label="分配审核员" className="px-3" />
                      <ActionButton label="发送催审" className="px-3" />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  } else if (activeView === 'rules') {
    workspace = (
      <div className="grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
        <Panel title="审核规则配置" description="配置合规检查触发条件、审核流程和通知方式。">
          <div className="space-y-4 text-sm text-slate-300">
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <Shield className="h-5 w-5 text-[#22c55e]" />
                合规与原创度阈值
              </div>
              <p className="mt-2 leading-6 text-slate-400">违禁词高亮级别：高；原创度提醒阈值：60%；触发后必须附带修改建议与审核备注。</p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <Users className="h-5 w-5 text-sky-300" />
                审核流程
              </div>
              <p className="mt-2 leading-6 text-slate-400">当前为单级审核 MVP；已预留升级到运营审核 → 法务审核 → 经理审核的多级流程入口。</p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <Clock3 className="h-5 w-5 text-amber-300" />
                通知策略
              </div>
              <p className="mt-2 leading-6 text-slate-400">支持系统消息、邮件、短信三种方式；MVP 阶段默认启用系统消息和站内催审。</p>
            </div>
          </div>
        </Panel>

        <Panel title="规则清单" description="所有规则支持记录修改历史，并关联生效状态。">
          <CrudToolbar
            searchPlaceholder="搜索规则名称、阈值或通知方式"
            filters={['全部规则', '高优先级', '已生效']}
            right={<ActionButton label="新增规则" tone="accent" />}
          />
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="pb-3 font-medium">规则项</th>
                  <th className="pb-3 font-medium">当前值</th>
                  <th className="pb-3 font-medium">触发条件</th>
                  <th className="pb-3 font-medium">通知方式</th>
                </tr>
              </thead>
              <tbody>
                {ruleRows.map((rule) => (
                <tr key={rule.item} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{rule.item}</td>
                    <td className="py-4 pr-4">{rule.value}</td>
                  <td className="py-4 pr-4 text-slate-400">{rule.trigger}</td>
                  <td className="py-4 pr-4 text-slate-400">{rule.notify}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </div>
    );
  } else if (activeView === 'records') {
    workspace = (
      <Panel title="审核记录管理" description="审核轨迹不可删除，满足合规审计要求。">
        <CrudToolbar
          searchPlaceholder="搜索脚本 ID、审核动作、操作人或时间"
          filters={['近 7 天', '全部品牌', '审核通过 / 驳回']}
          right={<ActionButton label="导出审核记录" />}
        />
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="pb-3 font-medium">脚本 ID</th>
                <th className="pb-3 font-medium">操作人</th>
                <th className="pb-3 font-medium">审核动作</th>
                <th className="pb-3 font-medium">时间</th>
                <th className="pb-3 font-medium">记录详情</th>
              </tr>
            </thead>
            <tbody>
              {records.map((record) => (
                <tr key={`${record.id}-${record.time}`} className="border-t border-white/10 text-slate-200">
                  <td className="py-4 pr-4 font-medium text-slate-50">{record.id}</td>
                  <td className="py-4 pr-4">{record.actor}</td>
                  <td className="py-4 pr-4">
                    <StatusBadge label={record.action} tone={record.action === '审核通过' ? 'success' : 'neutral'} />
                  </td>
                  <td className="py-4 pr-4">{record.time}</td>
                  <td className="py-4 pr-4 text-slate-400">{record.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Module 03"
        title="生成与审核工作流管理"
        description="围绕前台步骤 4 的脚本审核建立单级审核能力，覆盖审核席位、任务分配、规则配置和审核记录，满足管理端 MVP 要求。"
        tags={[
          { label: 'MVP 优先', tone: 'accent' },
          { label: '审核轨迹不可删除', tone: 'warning' },
        ]}
        action={<ActionButton label="创建审核任务" tone="accent" />}
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="待审核脚本" value="46" detail="系统会按照提交时间排序，并支持品牌、状态、阶段筛选。" tone="warning" />
        <MetricCard label="活跃审核席位" value="12" detail="支持按品牌分配审核员账号，当前为单级审核流程。" tone="accent" />
        <MetricCard label="平均审核时长" value="2.6h" detail="超时任务将进入催审队列并发送系统提醒。" tone="success" />
        <MetricCard label="近 7 天驳回率" value="14%" detail="主要集中在违禁词高亮和原创度接近阈值的脚本。" tone="neutral" />
      </div>

      <SectionTabs items={sectionItems} activeItem={activeView} onChange={onViewChange} />

      {workspace}
    </div>
  );
}
