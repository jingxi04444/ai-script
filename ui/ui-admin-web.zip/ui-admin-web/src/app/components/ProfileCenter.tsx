import { LockKeyhole, MoonStar, ShieldCheck, UserCircle2 } from 'lucide-react';
import { ActionButton, PageHeader, Panel, SectionTabs, StatusBadge } from './shared';

const sectionItems = [
  { id: 'personal-info', label: '基础资料' },
  { id: 'account-security', label: '安全设置' },
];

export default function ProfileCenter({
  activeView,
  onViewChange,
  userName,
  userEmail,
  roleLabel,
  shellTheme,
}: {
  activeView: string;
  onViewChange: (view: string) => void;
  userName: string;
  userEmail: string;
  roleLabel: string;
  shellTheme: 'default' | 'oled';
}) {
  const infoRows = [
    ['昵称', userName],
    ['邮箱', userEmail],
    ['手机号', '13800000000'],
    ['密码', '修改密码'],
    ['角色', roleLabel],
    ['账号状态', '已批准'],
    ['注册时间', '2026-04-20 09:18'],
    ['到期时间', '2038-01-06 23:59（剩余 4280 天）'],
  ];

  let workspace = (
    <Panel title="个人信息" description="查看当前后台管理员账号的基础资料、角色信息与账号状态。">
      <div className="overflow-x-auto rounded-[22px] border border-white/10 bg-white/[0.03]">
        <table className="min-w-full text-left text-sm">
          <tbody>
            {infoRows.map(([label, value]) => (
              <tr key={label} className="border-t border-white/10 first:border-t-0">
                <td className="w-[240px] bg-white/[0.03] px-5 py-4 font-medium text-slate-300">{label}</td>
                <td className="px-5 py-4 text-slate-100">
                  {label === '密码' ? (
                    <button className="text-[#60a5fa] hover:text-[#93c5fd]">{value}</button>
                  ) : label === '账号状态' ? (
                    <StatusBadge label={value} tone="success" />
                  ) : label === '角色' ? (
                    <StatusBadge label={value} tone="warning" />
                  ) : label === '到期时间' ? (
                    <span className="text-[#84cc16]">{value}</span>
                  ) : (
                    value
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );

  if (activeView === 'account-security') {
    workspace = (
      <div className="grid gap-6 xl:grid-cols-[1fr_1fr]">
        <Panel title="安全设置" description="管理登录方式、密码修改和二次验证。">
          <div className="space-y-4">
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <LockKeyhole className="h-5 w-5 text-[#22c55e]" />
                登录凭证
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-400">当前启用账号密码登录，支持修改密码与强制下次登录重新验证。</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <ActionButton label="修改密码" />
                <ActionButton label="下次登录重置验证" tone="accent" />
              </div>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <ShieldCheck className="h-5 w-5 text-sky-300" />
                二次验证
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-400">超级管理员强制启用二次验证，品牌管理员可按租户策略配置。</p>
              <div className="mt-3">
                <StatusBadge label="MFA 已启用" tone="success" />
              </div>
            </div>
          </div>
        </Panel>

        <Panel title="界面偏好" description="管理当前后台主题和常用交互偏好。">
          <div className="space-y-4">
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <MoonStar className="h-5 w-5 text-amber-300" />
                当前主题
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-400">当前后台主题为 {shellTheme === 'default' ? '标准暗色' : 'OLED 暗色'}，可通过顶部按钮快速切换。</p>
            </div>
            <div className="rounded-[22px] border border-white/10 bg-white/[0.03] p-4">
              <div className="flex items-center gap-3 text-slate-50">
                <UserCircle2 className="h-5 w-5 text-[#22c55e]" />
                个人偏好
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-400">收藏菜单、快捷新建和主题设置会跟随当前账号保存。</p>
            </div>
          </div>
        </Panel>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Account Center"
        title="个人信息"
        description="这是后台管理系统的账号中心页面，可查看基础资料、安全设置和界面偏好。"
        tags={[
          { label: roleLabel, tone: 'warning' },
          { label: '账号中心', tone: 'accent' },
        ]}
        action={<ActionButton label="编辑资料" tone="accent" />}
      />

      <SectionTabs items={sectionItems} activeItem={activeView} onChange={onViewChange} />

      {workspace}
    </div>
  );
}
