import type { LucideIcon } from 'lucide-react';
import { ChevronRight, Lock, Shield } from 'lucide-react';

interface ModuleItem {
  id: string;
  section: string;
  label: string;
  caption: string;
  icon: LucideIcon;
  roles: string[];
  stage: 'mvp' | 'extended' | 'future';
  children: Array<{ id: string; label: string }>;
}

interface AdminSidebarProps {
  modules: ModuleItem[];
  activeModule: string;
  activeSubmodule: string;
  activeRole: string;
  activeTenantLabel: string;
  onModuleChange: (moduleId: string) => void;
  onSubmoduleChange: (submoduleId: string) => void;
}

function stageClassName(stage: ModuleItem['stage']) {
  if (stage === 'mvp') {
    return 'border-[#22c55e]/25 bg-[#22c55e]/10 text-[#bbf7d0]';
  }

  if (stage === 'extended') {
    return 'border-white/10 bg-white/5 text-slate-300';
  }

  return 'border-amber-400/20 bg-amber-400/10 text-amber-200';
}

function roleLabel(role: string) {
  if (role === 'super-admin') return '系统超级管理员';
  if (role === 'brand-admin') return '品牌专属管理员';
  if (role === 'reviewer') return '审核员';
  return '技术运维';
}

export default function AdminSidebar({
  modules,
  activeModule,
  activeSubmodule,
  activeRole,
  activeTenantLabel,
  onModuleChange,
  onSubmoduleChange,
}: AdminSidebarProps) {
  const groupedModules = modules.reduce<Record<string, ModuleItem[]>>((groups, module) => {
    if (!groups[module.section]) {
      groups[module.section] = [];
    }

    groups[module.section].push(module);
    return groups;
  }, {});

  return (
    <aside className="border-b border-white/10 bg-[rgba(7,12,24,0.96)] backdrop-blur-xl lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col lg:border-b-0">
      <div className="border-b border-white/10 px-4 py-5">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[#22c55e]/30 bg-[#22c55e]/10 text-lg font-semibold text-[#bbf7d0]">
            AI
          </div>
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-[0.28em] text-slate-500">Admin Console</div>
            <div className="mt-1 truncate text-[15px] font-semibold text-slate-50">短视频脚本后台中枢</div>
          </div>
        </div>
      </div>



    

      <nav className="flex gap-4 overflow-x-auto px-0 pb-4 lg:flex-1 lg:flex-col lg:overflow-visible lg:pb-5">
        {Object.entries(groupedModules).map(([section, sectionModules]) => (
          <div key={section} className="min-w-[248px] lg:min-w-0">
            <div className="mb-2 px-4 text-[11px] uppercase tracking-[0.24em] text-slate-500">{section}</div>
            <div className="space-y-1 px-2">
              {sectionModules.map((module) => {
                const Icon = module.icon;
                const isActive = activeModule === module.id;
                const isAllowed = module.roles.includes(activeRole);
                const hasChildren = module.children.length > 0;
                const stageLabel = module.stage === 'mvp' ? 'MVP' : module.stage === 'extended' ? '扩展' : '高阶';

                return (
                  <div key={module.id}>
                    <button
                      type="button"
                      onClick={() => isAllowed && onModuleChange(module.id)}
                      disabled={!isAllowed}
                      aria-disabled={!isAllowed}
                      className={`group flex w-full cursor-pointer items-center gap-3 rounded-2xl px-3 py-3 text-left ${
                        isActive
                          ? 'bg-[#22c55e]/12 text-slate-50 shadow-[inset_2px_0_0_0_#22c55e]'
                          : 'text-slate-300 hover:bg-white/[0.04]'
                      } ${!isAllowed ? 'cursor-not-allowed opacity-50' : ''}`}
                    >
                      <div
                        className={`flex h-9 w-9 flex-none items-center justify-center rounded-xl ${
                          isActive ? 'bg-[#22c55e]/12 text-[#bbf7d0]' : 'bg-white/[0.03] text-slate-400 group-hover:text-slate-200'
                        }`}
                      >
                        <Icon className="h-4.5 w-4.5" />
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className={`truncate text-sm font-semibold ${isActive ? 'text-slate-50' : 'text-slate-200'}`}>{module.label}</span>
                          {!isAllowed && <Lock className="h-4 w-4 text-slate-500" />}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className={`inline-flex h-6 items-center rounded-full border px-2.5 text-[10px] font-medium ${stageClassName(module.stage)}`}>
                          {stageLabel}
                        </span>
                        {hasChildren && (
                          <ChevronRight className={`h-4 w-4 transition-transform ${isActive ? 'rotate-90 text-slate-300' : 'text-slate-500'}`} />
                        )}
                      </div>
                    </button>

                    {isActive && isAllowed && hasChildren && (
                      <div className="ml-6 mt-1 border-l border-white/10 pl-4">
                        <div className="space-y-1 py-1">
                          {module.children.map((child) => {
                            const isChildActive = activeSubmodule === child.id;

                            return (
                              <button
                                key={child.id}
                                type="button"
                                onClick={() => onSubmoduleChange(child.id)}
                                className={`flex min-h-9 w-full cursor-pointer items-center justify-between rounded-xl px-3 text-left text-sm ${
                                  isChildActive
                                    ? 'bg-[#22c55e]/10 text-[#bbf7d0]'
                                    : 'text-slate-400 hover:bg-white/[0.04] hover:text-slate-200'
                                }`}
                              >
                                <span>{child.label}</span>
                                {isChildActive && <span className="h-2 w-2 rounded-full bg-[#22c55e]" />}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="hidden px-4 pb-5 lg:block">
        <div className="rounded-[18px] border border-white/10 bg-white/[0.03] p-3.5">
          <div className="text-sm font-semibold text-slate-100">权限边界提示</div>
          <p className="mt-2 text-sm leading-6 text-slate-400">
            导航会根据角色自动收敛。超级管理员查看全局模块，品牌管理员与审核员仅展示本品牌相关工作台。
          </p>
        </div>
      </div>
    </aside>
  );
}
