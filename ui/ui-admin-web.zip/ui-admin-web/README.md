# AI Script Admin UI

后台管理端 UI，基于 Vite + React 构建。

## Running the code

Run `npm install` to install dependencies.

Run `npm run dev` to start the development server.

Run `npm run build` to build the production bundle.
